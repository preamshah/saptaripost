# Admin Guide

The complete administrator and editorial workflow guide is in [`documentation/ADMIN-GUIDE.md`](documentation/ADMIN-GUIDE.md).
