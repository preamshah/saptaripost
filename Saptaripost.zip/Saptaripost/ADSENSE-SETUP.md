# AdSense Setup

Advertising placement, consent and AdSense preparation guidance is in [`documentation/ADSENSE-SETUP.md`](documentation/ADSENSE-SETUP.md).
