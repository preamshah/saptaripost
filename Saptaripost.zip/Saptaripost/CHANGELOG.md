# Changelog

## 1.0.0 — 2026-08-28

- Initial Saptari Post PHP/MySQL release
- Responsive bilingual public portal and article experience
- Reader authentication, bookmarks, reactions, moderated comments and password recovery
- Role-aware newsroom dashboard, article revisions, scheduling, media validation and advertising
- Normalized database, realistic demo records, SEO/news feeds and deployment documentation
- Supplied Saptari Post logo and favicon integrated
