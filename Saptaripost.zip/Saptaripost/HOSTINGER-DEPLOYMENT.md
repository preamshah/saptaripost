# Saptari Post — Hostinger Deployment

This package is configured for `https://www.saptaripost.com` and should be extracted directly into the domain's `public_html` directory.

## Required structure

The `.env`, `.htaccess`, `app`, `config`, `database`, `public`, `routes`, `scripts`, and `storage` items must be directly inside `public_html`. Do not keep an additional `saptaripost-hostinger-ready` directory around them.

## Database

1. Open hPanel > Databases > Management > phpMyAdmin.
2. Select database `u438042804_Saptarinews`.
3. Import `database/schema.sql` first.
4. Import `database/demo-data.sql` second.

The included `.env` already contains the supplied database name, username, password, domain, secure-session setting, and a generated application key.

## Hostinger settings

- Use PHP 8.2 or newer.
- Keep file permissions at 644 and directory permissions at 755.
- Ensure `storage/cache`, `storage/logs`, `storage/backups`, and `public/uploads` are writable.
- Enable SSL and force HTTPS.
- Delete the uploaded ZIP after extracting it.

## Final checks

Open `/`, `/login`, `/admin`, `/assets/css/app.css`, `/sitemap.xml`, and `/robots.txt`. The `.env` URL must return 403 Forbidden.

The demo administrator password must be replaced immediately after deployment. Rotate the database password after the first successful launch because deployment credentials should not remain in transferred archives longer than necessary.
