# Installation and Deployment

## 1. Server requirements

Use PHP 8.2+, MySQL 8.0+ or MariaDB 10.6+, Apache/LiteSpeed, HTTPS and the PHP extensions `pdo_mysql`, `mbstring`, `fileinfo`, `dom`, `openssl` and `json`. Verify with `php -m` or cPanel **Select PHP Version**.

## 2. Upload or extract

- **XAMPP:** extract to `C:\xampp\htdocs\modern-nepal-news-portal`.
- **WAMP:** extract to the selected `www` directory.
- **Laragon:** extract to `C:\laragon\www\modern-nepal-news-portal`.
- **cPanel:** upload and extract above `public_html` when possible. Point the domain document root to `modern-nepal-news-portal/public`.

If shared hosting cannot change the document root, place the project in the domain root and keep the bundled root `.htaccess`. Test that `.env`, SQL and Markdown files return 403.

## 3. Create and import the database

Create a database named `saptari_post` with collation `utf8mb4_unicode_ci`. Create a least-privilege database user for that database. Import in this order:

1. `database/schema.sql`
2. `database/demo-data.sql`

With a terminal:

```bash
mysql -u YOUR_DB_USER -p saptari_post < database/schema.sql
mysql -u YOUR_DB_USER -p saptari_post < database/demo-data.sql
```

In phpMyAdmin, select the database, choose **Import**, and upload each file in the same order.

## 4. Configure `.env`

Copy `.env.example` to `.env`. Never serve, publish or commit `.env`.

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_URL=https://news.example.com
APP_TIMEZONE=Asia/Kathmandu
APP_KEY=generate-at-least-32-random-bytes
DB_HOST=localhost
DB_DATABASE=saptari_post
DB_USERNAME=saptari_post_user
DB_PASSWORD=use-a-unique-long-password
SESSION_SECURE=true
```

Generate `APP_KEY` with `php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"`.

## 5. File permissions

Files normally use `0644` and directories `0755`. Grant the PHP process write access only to:

- `public/uploads`
- `storage/cache`
- `storage/logs`
- `storage/backups`

On Linux hosting, `chmod -R 775` may be appropriate when the correct group owns these directories. Do not use `0777` unless the host explicitly requires it and no safer option exists.

## 6. Create the first administrator

The demo import includes:

```text
Email: admin@saptaripost.local
Password: ChangeMe!2026
```

Sign in and change it immediately. For a clean account, use:

```bash
php scripts/create-admin.php "Publisher Name" admin@example.com "a-unique-password-of-16-or-more-characters"
```

Delete demo users and stories only after creating and testing the replacement administrator.

## 7. SMTP and password recovery

Set `MAIL_ENABLED=true` and add the provider host, port, username, password, encryption and sender identity. The system generates one-hour, single-use, hashed reset tokens and uses a non-enumerating response. A mail transport is not bundled because cPanel, transactional-email and local SMTP configurations differ. Connect the mail-sending call at the documented point in `AuthController::forgot()` and test delivery, expiration and reuse prevention.

## 8. HTTPS and security

Install a valid TLS certificate, redirect HTTP to HTTPS at the host level, set `SESSION_SECURE=true`, keep `APP_DEBUG=false`, and verify that security headers are not overwritten by a proxy. Follow [SECURITY.md](documentation/SECURITY.md) before accepting registrations or uploads.

## 9. Scheduled publishing and cleanup

Scheduled stories remain unpublished until the bundled worker changes their status. Run every minute or every five minutes:

```cron
*/5 * * * * /usr/local/bin/php /absolute/path/scripts/publish-scheduled.php >/dev/null 2>&1
```

Change the PHP and project paths for the host. The script also removes expired password/email tokens and login-attempt records older than 30 days.

## 10. Analytics, Search Console and advertising

- Add Search Console and Bing verification values to `.env` or the settings table.
- Add GA4/GTM only after consent requirements have been reviewed.
- Leave `ads.txt` commented until an authorized seller ID exists.
- Use the admin ad manager for direct campaigns. Treat third-party JavaScript as trusted code available only to administrators.

See [SEO-GUIDE.md](documentation/SEO-GUIDE.md) and [ADSENSE-SETUP.md](documentation/ADSENSE-SETUP.md).

## 11. Backups

Back up the database and `public/uploads` together. Keep encrypted copies outside the web server and test restoration quarterly. A typical database backup is:

```bash
mysqldump --single-transaction --routines --triggers -u DB_USER -p saptari_post > saptari-post-YYYY-MM-DD.sql
```

Never leave `.sql` backups under the public document root.

## 12. Moving localhost to live hosting

1. Export the local database and import it on the live server.
2. Upload code and `public/uploads`.
3. Create a production `.env`; do not reuse local database credentials.
4. Set the final HTTPS `APP_URL`.
5. Clear `storage/cache`, test log permissions and configure cron.
6. Verify login, upload, article publishing, search, comments, sitemaps, RSS, 403/404/500 behavior and email.
7. Remove demo records and launch markers.

## 13. Disable installation artifacts

There is no web installer to attack. After a successful deployment, remove database import files from the live server or keep them outside the web root. The bundled rules block direct web access, but removing unnecessary copies is safer.
