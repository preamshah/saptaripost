# Saptari Post News Portal

Saptari Post is a bilingual, Nepal-focused digital-news platform built with PHP 8.2, PDO, MySQL/MariaDB, Bootstrap 5 and lightweight vanilla JavaScript. It includes a responsive public portal, reader accounts, a role-aware newsroom dashboard, editorial workflow, secure media uploads, structured data, XML/news sitemaps, RSS, responsive advertising placements and launch documentation.

## Requirements

- PHP 8.2 or newer with PDO MySQL, mbstring, fileinfo, DOM and OpenSSL
- MySQL 8.0+ or MariaDB 10.6+
- Apache 2.4 or LiteSpeed with `mod_rewrite`; HTTPS strongly recommended
- PHP GD is optional for future thumbnail/WebP extensions
- No Node.js production dependency

The runtime requirements follow the supported PHP language and password APIs documented by [PHP](https://www.php.net/supported-versions.php) and [PHP password hashing](https://www.php.net/manual/en/function.password-hash.php). Database setup targets [MySQL 8.0](https://dev.mysql.com/doc/refman/8.0/en/) and equivalent MariaDB features.

## Quick installation

1. Extract the project into XAMPP `htdocs`, Laragon `www`, WAMP `www`, or a cPanel domain directory.
2. Copy `.env.example` to `.env`; set `APP_URL`, a long random `APP_KEY`, and database credentials.
3. Create a database named `saptari_post` using `utf8mb4_unicode_ci`.
4. Import `database/schema.sql`, then `database/demo-data.sql`.
5. Point the domain document root at `/public`. If that is unavailable, the root `.htaccess` forwards requests to `/public`.
6. Ensure `public/uploads`, `storage/cache`, `storage/logs` and `storage/backups` are writable by PHP, but not world-writable.
7. Open the configured `APP_URL` and sign in at `/login`.

See [INSTALLATION.md](INSTALLATION.md) for XAMPP, cPanel, HTTPS, cron, migration and backup details.

## Demo administrator

- URL: `/login`
- Email: `admin@saptaripost.local`
- Password: `ChangeMe!2026`

**Change the password, email and profile immediately.** Demo accounts have `must_change_password=1`. For a clean production admin, run `php scripts/create-admin.php "Publisher Name" admin@example.com "a-long-unique-password"` after importing the schema, then remove demo accounts and data.

## Main capabilities

- Mobile-first public homepage with breaking ticker, lead stories, latest, most-read, editor selections, category blocks and newsletter form
- Article pages with author transparency, timestamps, reading time, view counts, print/font controls, reactions, bookmarks, sharing, moderated comments and correction requests
- Search filters and category, province, author, video, photo and opinion archives
- Reader registration, login, rate limiting, password recovery, bookmarks and session-only reading history
- Role and permission schema for seven roles; role-aware publishing rules for contributors and reporters
- Article create/edit/revision/schedule/publish/trash flow with server-side HTML sanitization and browser-local draft autosave
- Secure image validation using MIME inspection, decoded-image checks, randomized names and upload execution blocking
- Admin views for articles, media, categories, comments, advertisements, settings, users, tags, messages, subscribers, polls, galleries, menus, redirects, homepage sections and activity logs
- Canonical metadata, Open Graph, X cards, NewsArticle and organization JSON-LD, RSS, sitemap index and Google News sitemap
- Responsive, labelled ad reservations with campaign dates, devices, impression/click schema and direct-ad redirect tracking
- English/Nepali Unicode content, language files and linked-translation architecture
- Custom 403, 404, 500 and maintenance pages; print and reduced-motion styles

## Directory map

```text
app/            Controllers, models, core, middleware, services and views
config/         Application, database and security configuration
database/       Normalized schema and demo records
documentation/  Admin, security, SEO and advertising guides
language/       English and Nepali interface dictionaries
public/         Front controller, local assets, protected uploads, ads.txt
routes/         Public, reader and admin routes
scripts/        Admin provisioning and scheduled-publishing utilities
storage/        Cache, logs and backup destinations
tests/          Static verification utility
```

## Before launch

Replace all text marked `CUSTOMIZE BEFORE LAUNCH`; set the registered publisher, ownership, funding, editor-in-chief, office address, phone, legal registrations, final policies, email delivery, social URLs, real licensed media and verified stories. Configure analytics or advertising only after implementing an appropriate consent policy. Google News and AdSense approval are never guaranteed.

## Known limitations

- SMTP transport, CAPTCHA, live weather, stock data and analytics vendors require the publisher’s own credentials and provider integration; forms fail safely or store requests without exposing secrets.
- Bootstrap uses the official jsDelivr CDN while the complete core layout has local fallback styling. Download Bootstrap locally if the deployment must work with no external network.
- The supplied admin UI provides full CRUD for core editorial operations; secondary modules are safely listed and use normalized tables, with extension patterns documented in the admin guide.
- Automatic thumbnails/WebP conversion requires GD or Imagick and is intentionally left as an extension point; uploads are validated and stored in their accepted format.
- Database integration tests require a configured MySQL instance. `tests/verify.php` performs static packaging checks without a database.

## License

The application source and original placeholder illustrations are licensed under the MIT License. The supplied Saptari Post logo and favicon remain the uploader’s assets. Demo content is fictional and must not be presented as live reporting.
