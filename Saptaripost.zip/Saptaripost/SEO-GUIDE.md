# SEO Guide

Technical SEO and Google News readiness guidance is in [`documentation/SEO-GUIDE.md`](documentation/SEO-GUIDE.md).
