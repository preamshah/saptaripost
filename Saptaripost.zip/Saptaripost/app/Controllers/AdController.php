<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;

final class AdController
{
    public function click(string $id): void
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT destination_url FROM advertisements WHERE id = ? AND is_active = 1 AND ad_type = "image" LIMIT 1');
        $stmt->execute([(int) $id]);
        $destination = $stmt->fetchColumn();
        if (!$destination || !filter_var($destination, FILTER_VALIDATE_URL)) {
            http_response_code(404);
            exit('Advertisement not found.');
        }
        Database::transaction(static function (\PDO $pdo) use ($id): void {
            $pdo->prepare('UPDATE advertisements SET clicks_count = clicks_count + 1 WHERE id = ?')->execute([(int) $id]);
            $pdo->prepare('INSERT INTO ad_clicks (advertisement_id, session_hash, created_at) VALUES (?, ?, NOW())')->execute([(int) $id, hash('sha256', session_id())]);
        });
        header('Location: ' . $destination, true, 302);
        exit;
    }
}
