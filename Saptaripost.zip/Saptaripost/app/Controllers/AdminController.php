<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\Category;
use App\Services\HtmlSanitizer;
use App\Services\UploadService;
use PDO;

final class AdminController extends Controller
{
    public function dashboard(): void
    {
        $pdo = Database::connection();
        $stats = [
            'articles' => (int) $pdo->query('SELECT COUNT(*) FROM articles WHERE deleted_at IS NULL')->fetchColumn(),
            'published' => (int) $pdo->query("SELECT COUNT(*) FROM articles WHERE status = 'published' AND deleted_at IS NULL")->fetchColumn(),
            'pending_comments' => (int) $pdo->query("SELECT COUNT(*) FROM comments WHERE status = 'pending'")->fetchColumn(),
            'subscribers' => (int) $pdo->query("SELECT COUNT(*) FROM newsletter_subscribers WHERE status <> 'unsubscribed'")->fetchColumn(),
            'views' => (int) $pdo->query('SELECT COALESCE(SUM(views_count),0) FROM articles')->fetchColumn(),
        ];
        $recent = $pdo->query('SELECT a.id, a.title, a.status, a.updated_at, u.name AS author_name FROM articles a JOIN users u ON u.id = a.author_id WHERE a.deleted_at IS NULL ORDER BY a.updated_at DESC LIMIT 8')->fetchAll();
        $this->view('admin/dashboard', ['title' => 'Dashboard', 'stats' => $stats, 'recent' => $recent], 'layouts/admin');
    }

    public function articles(): void
    {
        $pdo = Database::connection();
        $where = 'a.deleted_at IS NULL';
        $params = [];
        if (in_array(Auth::user()['role_slug'], ['reporter', 'contributor'], true)) {
            $where .= ' AND a.author_id = ?';
            $params[] = Auth::user()['id'];
        }
        $status = $_GET['status'] ?? '';
        if (in_array($status, ['draft', 'pending_review', 'scheduled', 'published', 'rejected'], true)) {
            $where .= ' AND a.status = ?';
            $params[] = $status;
        }
        $stmt = $pdo->prepare("SELECT a.*, c.name AS category_name, u.name AS author_name FROM articles a JOIN categories c ON c.id = a.category_id JOIN users u ON u.id = a.author_id WHERE {$where} ORDER BY a.updated_at DESC LIMIT 100");
        $stmt->execute($params);
        $this->view('admin/articles', ['title' => 'Articles', 'articles' => $stmt->fetchAll()], 'layouts/admin');
    }

    public function articleForm(string $id = 'new'): void
    {
        if ($id === 'new') {
            $this->authorize('articles.create');
        }
        $article = null;
        if ($id !== 'new') {
            $stmt = Database::connection()->prepare('SELECT a.*, c.slug AS category_slug FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.id = ? AND a.deleted_at IS NULL');
            $stmt->execute([(int) $id]);
            $article = $stmt->fetch();
            if (!$article || (in_array(Auth::user()['role_slug'], ['reporter', 'contributor'], true) && (int) $article['author_id'] !== (int) Auth::user()['id'])) {
                http_response_code(403);
                $this->view('errors/403', ['title' => 'Access denied']);
                return;
            }
            if (!in_array(Auth::user()['role_slug'], ['reporter', 'contributor'], true) && !Auth::can('articles.edit_all')) {
                $this->authorize('articles.edit_all');
            }
        }
        $this->view('admin/article-form', ['title' => $article ? 'Edit Article' : 'New Article', 'article' => $article, 'categories' => Category::all()], 'layouts/admin');
    }

    public function saveArticle(string $id = 'new'): void
    {
        $this->authorize('articles.create');
        $this->validateCsrf();
        $title = trim((string) ($_POST['title'] ?? ''));
$categoryId = (int) ($_POST['category_id'] ?? 0);
$body = HtmlSanitizer::clean($_POST['body'] ?? '');

$bodyText = trim(
    html_entity_decode(
        strip_tags($body),
        ENT_QUOTES | ENT_HTML5,
        'UTF-8'
    )
);

$slugInput = trim((string) ($_POST['slug'] ?? ''));
$slugSource = $slugInput !== '' ? $slugInput : $title;

$slug = trim(
    preg_replace(
        '/[^a-z0-9]+/',
        '-',
        strtolower($slugSource)
    ) ?? '',
    '-'
);

/* Create a fallback slug for Nepali-only titles */
if ($slug === '') {
    $slug = 'news-' . date('Ymd-His') . '-' . bin2hex(random_bytes(2));
}

$redirectPath = '/admin/articles/' .
    ($id === 'new' ? 'new' : $id . '/edit');

if (mb_strlen($title, 'UTF-8') < 0) {
    $this->redirect(
        $redirectPath,
        'The headline must contain at least characters.',
        'error'
    );
}

if ($categoryId < 1) {
    $this->redirect(
        $redirectPath,
        'Please select an article category.',
        'error'
    );
}

if (mb_strlen($bodyText, 'UTF-8') < 0) {
    $this->redirect(
        $redirectPath,
        'The article body must contain at least text characters.',
        'error'
    );
}
        $role = Auth::user()['role_slug'];
        $requestedStatus = $_POST['status'] ?? 'draft';
        $status = in_array($requestedStatus, ['draft', 'pending_review', 'scheduled', 'published', 'rejected'], true) ? $requestedStatus : 'draft';
        if ($role === 'contributor' && !in_array($status, ['draft', 'pending_review'], true)) {
            $status = 'pending_review';
        }
        if ($role === 'reporter' && $status === 'published' && !Auth::can('articles.publish')) {
            $status = 'pending_review';
        }
        $publishedAt = trim($_POST['published_at'] ?? '') ?: null;
        if ($status === 'published' && !$publishedAt) {
            $publishedAt = date('Y-m-d H:i:s');
        }
        if ($status === 'scheduled' && (!$publishedAt || strtotime($publishedAt) <= time())) {
            $this->redirect('/admin/articles/' . ($id === 'new' ? 'new' : $id . '/edit'), 'Scheduled articles require a future publication time.', 'error');
        }
        $data = [
            'category_id' => (int) $_POST['category_id'], 'title' => $title, 'subtitle' => trim($_POST['subtitle'] ?? ''), 'slug' => $slug,
            'excerpt' => trim($_POST['excerpt'] ?? ''), 'body' => $body, 'featured_image' => trim($_POST['featured_image'] ?? 'assets/images/news-placeholder.svg'),
            'image_alt' => trim($_POST['image_alt'] ?? $title), 'image_caption' => trim($_POST['image_caption'] ?? ''), 'image_credit' => trim($_POST['image_credit'] ?? ''),
            'status' => $status, 'published_at' => $publishedAt, 'seo_title' => trim($_POST['seo_title'] ?? ''), 'meta_description' => trim($_POST['meta_description'] ?? ''),
            'canonical_url' => trim($_POST['canonical_url'] ?? ''), 'focus_keyword' => trim($_POST['focus_keyword'] ?? ''),
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0, 'is_breaking' => isset($_POST['is_breaking']) ? 1 : 0,
            'is_trending' => isset($_POST['is_trending']) ? 1 : 0, 'is_editors_pick' => isset($_POST['is_editors_pick']) ? 1 : 0,
            'is_exclusive' => isset($_POST['is_exclusive']) ? 1 : 0, 'is_live' => isset($_POST['is_live']) ? 1 : 0,
            'is_video' => isset($_POST['is_video']) ? 1 : 0, 'allow_comments' => isset($_POST['allow_comments']) ? 1 : 0,
        ];
        $pdo = Database::connection();
        if ($id === 'new') {
            $fields = array_keys($data);
            $sql = 'INSERT INTO articles (author_id, ' . implode(', ', $fields) . ', created_at, updated_at) VALUES (:author_id, :' . implode(', :', $fields) . ', NOW(), NOW())';
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['author_id' => Auth::user()['id']] + $data);
            $id = (string) $pdo->lastInsertId();
        } else {
            $stmt = $pdo->prepare('SELECT * FROM articles WHERE id = ?');
            $stmt->execute([(int) $id]);
            $before = $stmt->fetch();
            if (!$before) {
                $this->redirect('/admin/articles', 'Article not found.', 'error');
            }
            $pdo->prepare('INSERT INTO article_revisions (article_id, editor_id, title, body, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([$id, Auth::user()['id'], $before['title'], $before['body'], $before['status']]);
            $sets = implode(', ', array_map(static fn(string $field): string => $field . ' = :' . $field, array_keys($data)));
            $data['id'] = (int) $id;
            $pdo->prepare("UPDATE articles SET {$sets}, updated_at = NOW() WHERE id = :id")->execute($data);
        }
        $this->log('article.saved', 'articles', (int) $id, ['status' => $status]);
        $this->redirect('/admin/articles/' . $id . '/edit', 'Article saved successfully.');
    }

    public function deleteArticle(string $id): void
    {
        $this->validateCsrf();
        if (!Auth::can('articles.delete')) {
            http_response_code(403);
            exit('Forbidden');
        }
        Database::connection()->prepare('UPDATE articles SET deleted_at = NOW(), updated_at = NOW() WHERE id = ?')->execute([(int) $id]);
        $this->log('article.deleted', 'articles', (int) $id);
        $this->redirect('/admin/articles', 'Article moved to trash.');
    }

    public function categories(): void
    {
        $this->authorize('categories.manage');
        $this->view('admin/categories', ['title' => 'Categories', 'categories' => Category::all()], 'layouts/admin');
    }

    public function saveCategory(): void
    {
        $this->authorize('categories.manage');
        $this->validateCsrf();
        $name = trim($_POST['name'] ?? '');
        $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($_POST['slug'] ?: $name)), '-');
        if ($name === '' || $slug === '') {
            $this->redirect('/admin/categories', 'Name and slug are required.', 'error');
        }
        Database::connection()->prepare('INSERT INTO categories (parent_id, name, name_ne, slug, description, is_active, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, NOW(), NOW())')->execute([($_POST['parent_id'] ?? '') ?: null, $name, trim($_POST['name_ne'] ?? ''), $slug, trim($_POST['description'] ?? ''), (int) ($_POST['display_order'] ?? 0)]);
        $this->redirect('/admin/categories', 'Category created.');
    }

    public function comments(): void
    {
        $this->authorize('comments.moderate');
        $comments = Database::connection()->query('SELECT c.*, a.title AS article_title FROM comments c JOIN articles a ON a.id = c.article_id ORDER BY c.created_at DESC LIMIT 100')->fetchAll();
        $this->view('admin/comments', ['title' => 'Comments', 'comments' => $comments], 'layouts/admin');
    }

    public function moderateComment(string $id): void
    {
        $this->authorize('comments.moderate');
        $this->validateCsrf();
        $status = $_POST['status'] ?? 'pending';
        if (!in_array($status, ['approved', 'pending', 'spam', 'rejected'], true)) {
            $status = 'pending';
        }
        Database::connection()->prepare('UPDATE comments SET status = ?, moderated_by = ?, updated_at = NOW() WHERE id = ?')->execute([$status, Auth::user()['id'], (int) $id]);
        $this->redirect('/admin/comments', 'Comment status updated.');
    }

    public function media(): void
    {
        $this->authorize('media.manage');
        $media = Database::connection()->query('SELECT m.*, u.name AS uploader_name FROM media m LEFT JOIN users u ON u.id = m.uploaded_by ORDER BY m.created_at DESC LIMIT 100')->fetchAll();
        $this->view('admin/media', ['title' => 'Media Library', 'media' => $media], 'layouts/admin');
    }

    public function uploadMedia(): void
    {
        $this->authorize('media.manage');
        $this->validateCsrf();
        try {
            $image = UploadService::image($_FILES['image'] ?? []);
        } catch (\RuntimeException $e) {
            $this->redirect('/admin/media', $e->getMessage(), 'error');
        }
        Database::connection()->prepare('INSERT INTO media (uploaded_by, original_name, file_name, path, mime_type, file_size, width, height, alt_text, caption, credit, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())')->execute([
            Auth::user()['id'], $image['original_name'], basename($image['path']), $image['path'], $image['mime'], $image['size'], $image['width'], $image['height'], trim($_POST['alt_text'] ?? ''), trim($_POST['caption'] ?? ''), trim($_POST['credit'] ?? ''),
        ]);
        $this->redirect('/admin/media', 'Image uploaded securely.');
    }

    public function ads(): void
    {
        $this->authorize('ads.manage');
        $ads = Database::connection()->query('SELECT * FROM advertisements ORDER BY placement, display_order')->fetchAll();
        $this->view('admin/ads', ['title' => 'Advertisements', 'ads' => $ads], 'layouts/admin');
    }

    public function saveAd(): void
    {
        $this->authorize('ads.manage');
        $this->validateCsrf();
        $placements = ['header_banner','below_navigation','homepage_lead','between_cards','sidebar','above_article','inside_article','below_article','mobile_anchor','footer_banner'];
        $placement = $_POST['placement'] ?? '';
        if (!in_array($placement, $placements, true) || trim($_POST['name'] ?? '') === '') {
            $this->redirect('/admin/ads', 'A valid name and placement are required.', 'error');
        }
        Database::connection()->prepare('INSERT INTO advertisements (name, placement, ad_type, ad_code, image_path, destination_url, device_target, is_active, display_order, start_at, end_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())')->execute([
            trim($_POST['name']), $placement, $_POST['ad_type'] === 'code' ? 'code' : 'image', $_POST['ad_code'] ?? '', trim($_POST['image_path'] ?? ''), trim($_POST['destination_url'] ?? ''), $_POST['device_target'] ?? 'all', isset($_POST['is_active']) ? 1 : 0, (int) ($_POST['display_order'] ?? 0), ($_POST['start_at'] ?? '') ?: null, ($_POST['end_at'] ?? '') ?: null,
        ]);
        $this->redirect('/admin/ads', 'Advertisement created.');
    }

    public function settings(): void
    {
        $this->authorize('settings.manage');
        $settings = Database::connection()->query('SELECT * FROM settings ORDER BY group_name, setting_key')->fetchAll();
        $this->view('admin/settings', ['title' => 'Settings', 'settings' => $settings], 'layouts/admin');
    }

    public function saveSettings(): void
    {
        $this->authorize('settings.manage');
        $this->validateCsrf();
        $pdo = Database::connection();
        $stmt = $pdo->prepare('UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?');
        foreach ($_POST['settings'] ?? [] as $key => $value) {
            if (preg_match('/^[a-z0-9_.-]+$/', (string) $key)) {
                $stmt->execute([trim((string) $value), $key]);
            }
        }
        $this->log('settings.updated', 'settings', null);
        $this->redirect('/admin/settings', 'Settings updated.');
    }

    public function module(string $module): void
    {
        $allowed = [
            'users' => ['users', 'name', 'email', 'status'], 'tags' => ['tags', 'name', 'slug', 'created_at'],
            'messages' => ['contact_messages', 'name', 'email', 'status'], 'subscribers' => ['newsletter_subscribers', 'email', 'status', 'created_at'],
            'polls' => ['polls', 'question', 'status', 'created_at'], 'redirects' => ['redirects', 'source_path', 'target_url', 'http_code'],
            'activity' => ['activity_logs', 'action', 'entity_type', 'created_at'], 'homepage' => ['homepage_sections', 'section_key', 'title', 'is_active'],
            'menus' => ['menus', 'name', 'location', 'is_active'], 'galleries' => ['galleries', 'title', 'slug', 'published_at'],
        ];
        if (!isset($allowed[$module])) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Module not found']);
            return;
        }
        $table = $allowed[$module][0];
$columns = array_slice($allowed[$module], 1);
        $rows = Database::connection()->query('SELECT id, ' . implode(', ', $columns) . ' FROM ' . $table . ' ORDER BY id DESC LIMIT 100')->fetchAll();
        $this->view('admin/module', ['title' => ucwords($module), 'module' => $module, 'columns' => $columns, 'rows' => $rows], 'layouts/admin');
    }

    private function log(string $action, string $entity, ?int $entityId, array $metadata = []): void
    {
        Database::connection()->prepare('INSERT INTO activity_logs (user_id, action, entity_type, entity_id, metadata_json, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())')->execute([
            Auth::user()['id'], $action, $entity, $entityId, json_encode($metadata, JSON_UNESCAPED_UNICODE), hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . config('app.key')),
        ]);
    }

    private function authorize(string $permission): void
    {
        if (Auth::can($permission)) {
            return;
        }
        http_response_code(403);
        $this->view('errors/403', ['title' => 'Access denied']);
        exit;
    }
}
