<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;

final class ApiController
{
    public function suggestions(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $query = trim($_GET['q'] ?? '');
        if (mb_strlen($query) < 2) {
            echo '[]';
            return;
        }
        $stmt = Database::connection()->prepare("SELECT a.title, a.slug, c.slug AS category_slug FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.status = 'published' AND a.title LIKE ? AND a.deleted_at IS NULL ORDER BY a.published_at DESC LIMIT 6");
        $stmt->execute(['%' . $query . '%']);
        echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
