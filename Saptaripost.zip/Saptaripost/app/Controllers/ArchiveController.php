<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Article;
use App\Models\Category;
use App\Models\User;

final class ArchiveController extends Controller
{
    public function listing(string $type = 'latest'): void
    {
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $result = $type === 'trending'
            ? ['items' => Article::flagged('is_trending', 30), 'page' => 1, 'pages' => 1, 'total' => 30]
            : ($type === 'most-read'
                ? ['items' => Article::mostRead(30), 'page' => 1, 'pages' => 1, 'total' => 30]
                : Article::search([], $page, 12));
        $this->view('archives/listing', ['title' => ucwords(str_replace('-', ' ', $type)), 'result' => $result, 'heading' => ucwords(str_replace('-', ' ', $type))]);
    }

    public function category(string $slug): void
    {
        $category = Category::find($slug);
        if (!$category) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Category not found']);
            return;
        }
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $items = Article::latest(12, ($page - 1) * 12, (int) $category['id']);
        $stmt = Database::connection()->prepare("SELECT COUNT(*) FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.status = 'published' AND a.deleted_at IS NULL AND (c.id = ? OR c.parent_id = ?)");
        $stmt->execute([$category['id'], $category['id']]);
        $total = (int) $stmt->fetchColumn();
        $result = ['items' => $items, 'total' => $total, 'page' => $page, 'pages' => max(1, (int) ceil($total / 12))];
        $this->view('archives/listing', ['title' => $category['name'], 'heading' => $category['name'], 'description' => $category['description'], 'result' => $result, 'children' => Category::children((int) $category['id'])]);
    }

    public function search(): void
    {
        $filters = [
            'q' => trim($_GET['q'] ?? ''),
            'category' => trim($_GET['category'] ?? ''),
            'author' => trim($_GET['author'] ?? ''),
            'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'] ?? '') ? $_GET['date'] : '',
            'tag' => trim($_GET['tag'] ?? ''),
        ];
        $result = Article::search($filters, max(1, (int) ($_GET['page'] ?? 1)), 10);
        $this->view('archives/search', ['title' => 'Search', 'filters' => $filters, 'result' => $result, 'categories' => Category::all(), 'authors' => User::authors(), 'robots' => 'noindex,follow']);
    }

    public function tag(string $slug): void
    {
        $result = Article::search(['tag' => $slug], max(1, (int) ($_GET['page'] ?? 1)), 12);
        $this->view('archives/listing', ['title' => 'Tag: ' . ucwords(str_replace('-', ' ', $slug)), 'heading' => 'Tag: ' . ucwords(str_replace('-', ' ', $slug)), 'result' => $result]);
    }

    public function date(string $date): void
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Archive not found']);
            return;
        }
        $result = Article::search(['date' => $date], max(1, (int) ($_GET['page'] ?? 1)), 12);
        $this->view('archives/listing', ['title' => 'Archive: ' . $date, 'heading' => 'News from ' . date('F j, Y', strtotime($date)), 'result' => $result]);
    }

    public function authors(): void
    {
        $this->view('archives/authors', ['title' => 'Our Team', 'authors' => User::authors()]);
    }

    public function author(string $slug): void
    {
        $author = User::author($slug);
        if (!$author) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Author not found']);
            return;
        }
        $result = Article::search(['author' => $slug], max(1, (int) ($_GET['page'] ?? 1)), 10);
        $this->view('archives/author', ['title' => $author['name'], 'author' => $author, 'result' => $result]);
    }

    public function videos(): void
    {
        $this->view('archives/listing', ['title' => 'Video News', 'heading' => 'Video News', 'result' => ['items' => Article::flagged('is_video', 30), 'page' => 1, 'pages' => 1, 'total' => 30]]);
    }

    public function gallery(): void
    {
        $items = Database::connection()->query('SELECT * FROM galleries WHERE is_published = 1 ORDER BY published_at DESC')->fetchAll();
        $this->view('archives/gallery', ['title' => 'Photo Gallery', 'galleries' => $items]);
    }
}
