<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\Advertisement;
use App\Models\Article;

final class ArticleController extends Controller
{
    public function show(string $category, string $slug): void
    {
        $article = Article::find($category, $slug);
        if (!$article) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Article not found']);
            return;
        }
        $cookie = 'viewed_' . $article['id'];
        if (empty($_COOKIE[$cookie])) {
            Article::incrementView((int) $article['id']);
            setcookie($cookie, '1', ['expires' => time() + 1800, 'path' => '/', 'secure' => (bool) config('security.session_secure'), 'httponly' => true, 'samesite' => 'Lax']);
        }
        $_SESSION['reading_history'][$article['id']] = time();
        if (count($_SESSION['reading_history']) > 30) {
            asort($_SESSION['reading_history']);
            $_SESSION['reading_history'] = array_slice($_SESSION['reading_history'], -30, null, true);
        }
        $stmt = Database::connection()->prepare("SELECT c.*, u.name AS commenter_name FROM comments c LEFT JOIN users u ON u.id = c.user_id WHERE c.article_id = ? AND c.status = 'approved' AND c.parent_id IS NULL ORDER BY c.created_at DESC");
        $stmt->execute([$article['id']]);
        $this->view('articles/show', [
            'title' => $article['seo_title'] ?: $article['title'],
            'metaDescription' => $article['meta_description'] ?: excerpt($article['body']),
            'article' => $article,
            'comments' => $stmt->fetchAll(),
            'related' => Article::related($article),
            'adjacent' => Article::adjacent($article),
            'aboveAd' => Advertisement::placement('above_article'),
            'insideAd' => Advertisement::placement('inside_article'),
            'belowAd' => Advertisement::placement('below_article'),
            'canonical' => $article['canonical_url'] ?: url('/news/' . $category . '/' . $slug),
        ]);
    }

    public function comment(string $id): void
    {
        $this->validateCsrf();
        $name = trim($_POST['name'] ?? (Auth::user()['name'] ?? ''));
        $email = trim($_POST['email'] ?? (Auth::user()['email'] ?? ''));
        $body = trim($_POST['body'] ?? '');
        if (mb_strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($body) < 3 || mb_strlen($body) > 2000) {
            $this->redirect($this->articlePath((int) $id), 'Please provide a valid name, email and comment.', 'error');
        }
        $stmt = Database::connection()->prepare("INSERT INTO comments (article_id, user_id, guest_name, guest_email, body, status, ip_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'pending', ?, NOW(), NOW())");
        $stmt->execute([(int) $id, Auth::user()['id'] ?? null, $name, $email, $body, hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . config('app.key'))]);
        $this->redirect($this->articlePath((int) $id), 'Your comment was submitted for moderation.');
    }

    public function react(string $id): void
    {
        $this->validateCsrf();
        $type = $_POST['type'] ?? 'like';
        if (!in_array($type, ['like', 'love', 'insightful', 'concerned'], true)) {
            http_response_code(422);
            exit('Invalid reaction');
        }
        $pdo = Database::connection();
        $stmt = $pdo->prepare('INSERT INTO reactions (article_id, user_id, session_hash, reaction_type, created_at) VALUES (?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE reaction_type = VALUES(reaction_type)');
        $stmt->execute([(int) $id, Auth::user()['id'] ?? null, hash('sha256', session_id()), $type]);
        $this->redirect($this->articlePath((int) $id), 'Reaction saved.');
    }

    public function bookmark(string $id): void
    {
        $this->validateCsrf();
        $user = Auth::user();
        $stmt = Database::connection()->prepare('INSERT IGNORE INTO bookmarks (user_id, article_id, created_at) VALUES (?, ?, NOW())');
        $stmt->execute([$user['id'], (int) $id]);
        $this->redirect($this->articlePath((int) $id), 'Article saved to your dashboard.');
    }

    private function articlePath(int $id): string
    {
        $stmt = Database::connection()->prepare('SELECT a.slug, c.slug AS category_slug FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.id = ? LIMIT 1');
        $stmt->execute([$id]);
        $article = $stmt->fetch();
        return $article ? '/news/' . $article['category_slug'] . '/' . $article['slug'] : '/';
    }
}
