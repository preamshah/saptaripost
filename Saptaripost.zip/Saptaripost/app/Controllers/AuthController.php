<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\User;

final class AuthController extends Controller
{
    public function loginForm(): void
    {
        $this->view('auth/login', ['title' => 'Sign in', 'robots' => 'noindex,nofollow']);
    }

    public function login(): void
    {
        $this->validateCsrf();
        $email = mb_strtolower(trim($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $pdo = Database::connection();
        $ipHash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . config('app.key'));
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE email = ? AND ip_hash = ? AND was_successful = 0 AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)');
        $stmt->execute([$email, $ipHash]);
        if ((int) $stmt->fetchColumn() >= (int) config('security.login_max_attempts', 5)) {
            $this->redirect('/login', 'Too many attempts. Try again in 15 minutes.', 'error');
        }
        $success = Auth::attempt($email, $password);
        $pdo->prepare('INSERT INTO login_attempts (email, ip_hash, user_agent_hash, was_successful, attempted_at) VALUES (?, ?, ?, ?, NOW())')->execute([$email, $ipHash, hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? ''), $success ? 1 : 0]);
        if (!$success) {
            $_SESSION['_old'] = ['email' => $email];
            $this->redirect('/login', 'The email or password is incorrect.', 'error');
        }
        $target = in_array(Auth::user()['role_slug'], ['registered-reader'], true) ? '/reader' : '/admin';
        $this->redirect($target, 'Welcome back, ' . Auth::user()['name'] . '.');
    }

    public function registerForm(): void
    {
        $this->view('auth/register', ['title' => 'Create account', 'robots' => 'noindex,nofollow']);
    }

    public function register(): void
    {
        $this->validateCsrf();
        $data = ['name' => trim($_POST['name'] ?? ''), 'email' => trim($_POST['email'] ?? ''), 'password' => (string) ($_POST['password'] ?? '')];
        $_SESSION['_old'] = ['name' => $data['name'], 'email' => $data['email']];
        if (mb_strlen($data['name']) < 2 || !filter_var($data['email'], FILTER_VALIDATE_EMAIL) || strlen($data['password']) < 10 || $data['password'] !== ($_POST['password_confirmation'] ?? '')) {
            $this->redirect('/register', 'Use a valid name, email, matching password, and at least 10 characters.', 'error');
        }
        try {
            User::register($data);
        } catch (\InvalidArgumentException $e) {
            $this->redirect('/register', $e->getMessage(), 'error');
        }
        unset($_SESSION['_old']);
        $this->redirect('/login', 'Account created. You can now sign in.');
    }

    public function forgotForm(): void
    {
        $this->view('auth/forgot', ['title' => 'Reset password', 'robots' => 'noindex,nofollow']);
    }

    public function forgot(): void
    {
        $this->validateCsrf();
        $email = mb_strtolower(trim($_POST['email'] ?? ''));
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $pdo = Database::connection();
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            if ($userId = $stmt->fetchColumn()) {
                $token = bin2hex(random_bytes(32));
                $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$userId]);
                $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at, created_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR), NOW())')->execute([$userId, hash('sha256', $token)]);
                if (config('app.debug')) {
                    $_SESSION['_flash']['info'] = 'Development reset token: ' . $token;
                }
            }
        }
        $this->redirect('/forgot-password', 'If that address exists, password-reset instructions will be sent when SMTP is configured.');
    }

    public function resetForm(string $token): void
    {
        $stmt = Database::connection()->prepare('SELECT id FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1');
        $stmt->execute([hash('sha256', $token)]);
        if (!$stmt->fetchColumn()) {
            $this->redirect('/forgot-password', 'That reset link is invalid or has expired.', 'error');
        }
        $this->view('auth/reset', ['title' => 'Choose a new password', 'token' => $token, 'robots' => 'noindex,nofollow']);
    }

    public function reset(string $token): void
    {
        $this->validateCsrf();
        $password = (string) ($_POST['password'] ?? '');
        if (strlen($password) < 10 || $password !== ($_POST['password_confirmation'] ?? '')) {
            $this->redirect('/reset-password/' . rawurlencode($token), 'Use matching passwords with at least 10 characters.', 'error');
        }
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT id, user_id FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1');
        $stmt->execute([hash('sha256', $token)]);
        $reset = $stmt->fetch();
        if (!$reset) {
            $this->redirect('/forgot-password', 'That reset link is invalid or has expired.', 'error');
        }
        Database::transaction(static function (\PDO $pdo) use ($reset, $password): void {
            $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = NOW() WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $reset['user_id']]);
            $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ?')->execute([$reset['id']]);
            $pdo->prepare('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL')->execute([$reset['user_id']]);
        });
        $this->redirect('/login', 'Your password was updated. Sign in with the new password.');
    }

    public function logout(): void
    {
        $this->validateCsrf();
        Auth::logout();
        header('Location: ' . url('/'));
        exit;
    }
}
