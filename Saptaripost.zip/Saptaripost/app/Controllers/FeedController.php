<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Models\Article;

final class FeedController
{
    public function rss(): void
    {
        header('Content-Type: application/rss+xml; charset=utf-8');
        $articles = Article::latest(30);
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<rss version="2.0"><channel><title>' . e(config('app.name')) . '</title><link>' . e(url()) . '</link><description>Nepal news and analysis</description><language>en-NP</language>';
        foreach ($articles as $article) {
            $link = url('/news/' . $article['category_slug'] . '/' . $article['slug']);
            echo '<item><title>' . e($article['title']) . '</title><link>' . e($link) . '</link><guid>' . e($link) . '</guid><pubDate>' . date(DATE_RSS, strtotime($article['published_at'])) . '</pubDate><description>' . e($article['meta_description'] ?: excerpt($article['body'])) . '</description></item>';
        }
        echo '</channel></rss>';
    }

    public function sitemap(): void
    {
        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>' . e(url('/news-sitemap.xml')) . '</loc></sitemap><sitemap><loc>' . e(url('/page-sitemap.xml')) . '</loc></sitemap></sitemapindex>';
    }

    public function newsSitemap(): void
    {
        header('Content-Type: application/xml; charset=utf-8');
        $articles = Database::connection()->query("SELECT a.title, a.slug, a.published_at, c.slug AS category_slug FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.status = 'published' AND a.published_at >= DATE_SUB(NOW(), INTERVAL 2 DAY) AND a.deleted_at IS NULL ORDER BY a.published_at DESC")->fetchAll();
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">';
        foreach ($articles as $article) {
            echo '<url><loc>' . e(url('/news/' . $article['category_slug'] . '/' . $article['slug'])) . '</loc><news:news><news:publication><news:name>Saptari Post</news:name><news:language>en</news:language></news:publication><news:publication_date>' . e(date(DATE_ATOM, strtotime($article['published_at']))) . '</news:publication_date><news:title>' . e($article['title']) . '</news:title></news:news></url>';
        }
        echo '</urlset>';
    }

    public function pageSitemap(): void
    {
        header('Content-Type: application/xml; charset=utf-8');
        $pages = ['', 'latest', 'trending', 'most-read', 'authors', 'video-news', 'photo-gallery', 'about-us', 'contact', 'editorial-policy', 'privacy-policy'];
        echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        foreach ($pages as $page) {
            echo '<url><loc>' . e(url('/' . $page)) . '</loc></url>';
        }
        echo '</urlset>';
    }

    public function robots(): void
    {
        header('Content-Type: text/plain; charset=utf-8');
        echo "User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /login\nDisallow: /register\nDisallow: /search\nSitemap: " . url('/sitemap.xml') . "\n";
    }
}
