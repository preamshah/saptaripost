<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;

final class FormController extends Controller
{
    public function contact(): void
    {
        $this->storeMessage('contact');
    }

    public function advertise(): void
    {
        $this->storeMessage('advertise');
    }

    public function tip(): void
    {
        $this->storeMessage('news_tip');
    }

    private function storeMessage(string $type): void
    {
        $this->validateCsrf();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $subject = trim($_POST['subject'] ?? ucfirst(str_replace('_', ' ', $type)));
        $message = trim($_POST['message'] ?? '');
        $routes = ['contact' => '/contact', 'advertise' => '/advertise-with-us', 'news_tip' => '/submit-news-tip'];
        if (mb_strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($message) < 10 || mb_strlen($message) > 10000) {
            $this->redirect($routes[$type], 'Please complete all required fields correctly.', 'error');
        }
        $stmt = Database::connection()->prepare('INSERT INTO contact_messages (type, name, email, phone, subject, message, status, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, "new", ?, NOW())');
        $stmt->execute([$type, $name, $email, trim($_POST['phone'] ?? ''), $subject, $message, hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . config('app.key'))]);
        $this->redirect($routes[$type], 'Thank you. Your message has been received.');
    }

    public function correction(): void
    {
        $this->validateCsrf();
        $email = trim($_POST['email'] ?? '');
        $details = trim($_POST['details'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($details) < 20) {
            $this->redirect('/correction-request', 'Provide a valid email and enough detail to review the correction.', 'error');
        }
        Database::connection()->prepare('INSERT INTO correction_requests (article_url, name, email, details, evidence_url, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, "new", NOW(), NOW())')->execute([
            trim($_POST['article_url'] ?? ''), trim($_POST['name'] ?? ''), $email, $details, trim($_POST['evidence_url'] ?? ''),
        ]);
        $this->redirect('/correction-request', 'Your correction request has been logged for editorial review.');
    }

    public function newsletter(): void
    {
        $this->validateCsrf();
        $email = mb_strtolower(trim($_POST['email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->redirect('/', 'Enter a valid email address.', 'error');
        }
        $token = bin2hex(random_bytes(24));
        Database::connection()->prepare('INSERT INTO newsletter_subscribers (email, status, verification_token_hash, created_at, updated_at) VALUES (?, "pending", ?, NOW(), NOW()) ON DUPLICATE KEY UPDATE updated_at = NOW()')->execute([$email, hash('sha256', $token)]);
        $this->redirect('/', 'Subscription received. Verification email will be sent when SMTP is configured.');
    }

    public function poll(string $id): void
    {
        $this->validateCsrf();
        $option = (int) ($_POST['option_id'] ?? 0);
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM poll_options WHERE id = ? AND poll_id = ?');
        $stmt->execute([$option, (int) $id]);
        if (!$stmt->fetchColumn()) {
            $this->redirect('/', 'Choose a valid poll option.', 'error');
        }
        $pdo->prepare('INSERT IGNORE INTO poll_votes (poll_id, option_id, user_id, session_hash, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([(int) $id, $option, user()['id'] ?? null, hash('sha256', session_id()), hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . config('app.key'))]);
        $this->redirect('/', 'Your vote was recorded.');
    }
}
