<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Advertisement;
use App\Models\Article;
use App\Models\Category;
use App\Core\Database;

final class HomeController extends Controller
{
    public function index(): void
    {
        $categories = Category::all(true);
        $featured = Article::featured(5);
        $sections = [];
        foreach (['business-economy', 'technology', 'sports', 'entertainment', 'international', 'province-news'] as $slug) {
            $category = Category::find($slug);
            if ($category) {
                $sections[$slug] = ['category' => $category, 'articles' => Article::latest(4, 0, (int) $category['id'])];
            }
        }
        $poll = Database::connection()->query("SELECT * FROM polls WHERE status = 'active' AND (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at >= NOW()) ORDER BY created_at DESC LIMIT 1")->fetch();
        if ($poll) {
            $stmt = Database::connection()->prepare('SELECT * FROM poll_options WHERE poll_id = ? ORDER BY display_order');
            $stmt->execute([$poll['id']]);
            $poll['options'] = $stmt->fetchAll();
        }
        $this->view('home/index', [
            'title' => 'Saptari Post — Nepal News, Insight and Context',
            'metaDescription' => 'Independent Nepal news covering politics, business, technology, provinces, sports and important international developments.',
            'categories' => $categories,
            'featured' => $featured,
            'latest' => Article::latest(10),
            'breaking' => Article::flagged('is_breaking', 8),
            'trending' => Article::flagged('is_trending', 6),
            'mostRead' => Article::mostRead(6),
            'editorsPicks' => Article::flagged('is_editors_pick', 4),
            'videos' => Article::flagged('is_video', 4),
            'sections' => $sections,
            'headerAd' => Advertisement::placement('header_banner'),
            'poll' => $poll ?: null,
        ]);
    }
}
