<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class ReaderController extends Controller
{
    public function dashboard(): void
    {
        $stmt = Database::connection()->prepare("SELECT a.*, c.name AS category_name, c.slug AS category_slug FROM bookmarks b JOIN articles a ON a.id = b.article_id JOIN categories c ON c.id = a.category_id WHERE b.user_id = ? AND a.deleted_at IS NULL ORDER BY b.created_at DESC");
        $stmt->execute([Auth::user()['id']]);
        $history = [];
        if (!empty($_SESSION['reading_history'])) {
            $ids = array_map('intval', array_keys($_SESSION['reading_history']));
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $historyStmt = Database::connection()->prepare("SELECT a.*, c.name AS category_name, c.slug AS category_slug FROM articles a JOIN categories c ON c.id = a.category_id WHERE a.id IN ($placeholders)");
            $historyStmt->execute($ids);
            $history = $historyStmt->fetchAll();
        }
        $this->view('reader/dashboard', ['title' => 'Reader Dashboard', 'bookmarks' => $stmt->fetchAll(), 'history' => $history, 'robots' => 'noindex,nofollow']);
    }

    public function removeBookmark(string $id): void
    {
        $this->validateCsrf();
        $stmt = Database::connection()->prepare('DELETE FROM bookmarks WHERE user_id = ? AND article_id = ?');
        $stmt->execute([Auth::user()['id'], (int) $id]);
        $this->redirect('/reader', 'Bookmark removed.');
    }
}
