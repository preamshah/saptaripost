<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;

final class StaticController extends Controller
{
    private const PAGES = [
        'about-us' => ['About Us', 'about'],
        'contact' => ['Contact Us', 'contact'],
        'advertise-with-us' => ['Advertise With Us', 'advertise'],
        'submit-news-tip' => ['Submit a News Tip', 'tip'],
        'correction-request' => ['Correction Request', 'correction'],
        'privacy-policy' => ['Privacy Policy', 'policy'],
        'terms-and-conditions' => ['Terms and Conditions', 'policy'],
        'disclaimer' => ['Disclaimer', 'policy'],
        'cookie-policy' => ['Cookie Policy', 'policy'],
        'editorial-policy' => ['Editorial Policy', 'policy'],
        'corrections-policy' => ['Corrections Policy', 'policy'],
        'copyright-policy' => ['Copyright Policy', 'policy'],
        'community-guidelines' => ['Community Guidelines', 'policy'],
        'ownership-funding-disclosure' => ['Ownership and Funding Disclosure', 'policy'],
    ];

    public function show(string $slug): void
    {
        if (!isset(self::PAGES[$slug])) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Page not found']);
            return;
        }
        [$title, $template] = self::PAGES[$slug];
        $this->view('static/' . $template, ['title' => $title, 'slug' => $slug]);
    }

    public function maintenance(): void
    {
        http_response_code(503);
        header('Retry-After: 3600');
        $this->view('errors/maintenance', ['title' => 'Brief maintenance']);
    }
}
