<?php

declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function view(string $view, array $data = [], string $layout = 'layouts/main'): void
    {
        View::render($view, $data, $layout);
    }

    protected function redirect(string $path, string $message = '', string $type = 'success'): never
    {
        if ($message !== '') {
            $_SESSION['_flash'][$type] = $message;
        }
        header('Location: ' . url($path));
        exit;
    }

    protected function validateCsrf(): void
    {
        if (!Csrf::validate($_POST['_token'] ?? '')) {
            http_response_code(419);
            exit('The form expired. Go back, refresh the page, and try again.');
        }
    }
}
