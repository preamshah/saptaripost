<?php

declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\View;

if (!function_exists('env')) {
    function env(string $key, mixed $default = null): mixed
    {
        return $_ENV[$key] ?? $_SERVER[$key] ?? $default;
    }
}

if (!function_exists('config')) {
    function config(string $key, mixed $default = null): mixed
    {
        static $loaded = [];
        [$file, $item] = array_pad(explode('.', $key, 2), 2, null);
        if (!isset($loaded[$file])) {
            $path = dirname(__DIR__, 2) . '/config/' . $file . '.php';
            $loaded[$file] = is_file($path) ? require $path : [];
        }
        return $item === null ? $loaded[$file] : ($loaded[$file][$item] ?? $default);
    }
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return rtrim((string) config('app.url'), '/') . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

function old(string $key, string $default = ''): string
{
    return e($_SESSION['_old'][$key] ?? $default);
}

function flash(string $key, mixed $default = null): mixed
{
    $value = $_SESSION['_flash'][$key] ?? $default;
    unset($_SESSION['_flash'][$key]);
    return $value;
}

function user(): ?array
{
    return Auth::user();
}

function can(string $permission): bool
{
    return Auth::can($permission);
}

function __(string $key): string
{
    static $translations = [];
    $locale = $_SESSION['locale'] ?? config('app.locale', 'en');
    if (!isset($translations[$locale])) {
        $path = dirname(__DIR__, 2) . '/language/' . $locale . '/messages.php';
        $translations[$locale] = is_file($path) ? require $path : [];
    }
    return $translations[$locale][$key] ?? $key;
}

function reading_time(string $html): int
{
    $words = str_word_count(strip_tags($html));
    return max(1, (int) ceil($words / 220));
}

function excerpt(string $html, int $length = 155): string
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($html)) ?? '');
    return mb_strlen($text) <= $length ? $text : mb_substr($text, 0, $length - 1) . '…';
}
