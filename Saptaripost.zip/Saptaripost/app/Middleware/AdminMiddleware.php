<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\View;

final class AdminMiddleware
{
    public function handle(): void
    {
        $user = Auth::user();
        if (!$user) {
            header('Location: ' . url('/login'));
            exit;
        }
        if (!in_array($user['role_slug'], ['super-administrator', 'administrator', 'editor', 'reporter', 'contributor', 'moderator'], true)) {
            http_response_code(403);
            View::render('errors/403', ['title' => 'Access denied']);
            exit;
        }

        if ($user['role_slug'] === 'editor') {
            $requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
            $appPath = parse_url((string) config('app.url'), PHP_URL_PATH) ?: '';

            if ($appPath !== '' && $appPath !== '/' && str_starts_with($requestPath, $appPath)) {
                $requestPath = substr($requestPath, strlen($appPath)) ?: '/';
            }

            $requestPath = '/' . trim($requestPath, '/');

            if ($requestPath === '/admin') {
                header('Location: ' . url('/admin/articles'));
                exit;
            }

            $canAccessArticles = $requestPath === '/admin/articles'
                || str_starts_with($requestPath, '/admin/articles/');
            $canAccessMedia = $requestPath === '/admin/media';

            $isDeleteRequest = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
                && preg_match('#^/admin/articles/[^/]+/delete$#', $requestPath) === 1;

            if ($isDeleteRequest || (!$canAccessArticles && !$canAccessMedia)) {
                http_response_code(403);
                View::render('errors/403', ['title' => 'Access denied']);
                exit;
            }
        }
    }
}
