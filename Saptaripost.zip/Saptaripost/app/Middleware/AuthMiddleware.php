<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;

final class AuthMiddleware
{
    public function handle(): void
    {
        if (!Auth::user()) {
            $_SESSION['_flash']['error'] = 'Please sign in to continue.';
            header('Location: ' . url('/login'));
            exit;
        }
    }
}
