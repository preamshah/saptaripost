<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Advertisement
{
    public static function placement(string $placement): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM advertisements WHERE placement = ? AND is_active = 1 AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW()) ORDER BY display_order LIMIT 1');
        $stmt->execute([$placement]);
        $ad = $stmt->fetch() ?: null;
        if ($ad && empty($_SESSION['ad_impressions'][$ad['id']])) {
            $pdo = Database::connection();
            $pdo->prepare('UPDATE advertisements SET impressions_count = impressions_count + 1 WHERE id = ?')->execute([$ad['id']]);
            $pdo->prepare('INSERT INTO ad_impressions (advertisement_id, session_hash, device_type, created_at) VALUES (?, ?, ?, NOW())')->execute([
                $ad['id'], hash('sha256', session_id()), preg_match('/Mobile|Android|iPhone/i', $_SERVER['HTTP_USER_AGENT'] ?? '') ? 'mobile' : 'desktop',
            ]);
            $_SESSION['ad_impressions'][$ad['id']] = true;
        }
        return $ad;
    }
}
