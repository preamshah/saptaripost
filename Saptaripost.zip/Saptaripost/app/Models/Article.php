<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

final class Article
{
    private static function publishedWhere(): string
    {
        return "a.status = 'published' AND a.published_at <= NOW() AND a.deleted_at IS NULL";
    }

    private static function select(): string
    {
        return 'SELECT a.*, c.name AS category_name, c.slug AS category_slug, c.parent_id, u.name AS author_name, u.slug AS author_slug, u.avatar AS author_avatar FROM articles a JOIN categories c ON c.id = a.category_id JOIN users u ON u.id = a.author_id ';
    }

    public static function latest(int $limit = 12, int $offset = 0, ?int $categoryId = null): array
    {
        $sql = self::select() . ' WHERE ' . self::publishedWhere();
        $params = [];
        if ($categoryId) {
    $sql .= ' AND (c.id = :category_id OR c.parent_id = :parent_category_id)';
    $params['category_id'] = $categoryId;
    $params['parent_category_id'] = $categoryId;
    }
        $sql .= ' ORDER BY a.published_at DESC LIMIT :limit OFFSET :offset';
        $stmt = Database::connection()->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(':' . $key, $value, PDO::PARAM_INT);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function featured(int $limit = 5): array
    {
        $stmt = Database::connection()->prepare(self::select() . ' WHERE ' . self::publishedWhere() . ' AND a.is_featured = 1 ORDER BY a.featured_order, a.published_at DESC LIMIT :limit');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function flagged(string $flag, int $limit = 8): array
    {
        $allowed = ['is_breaking', 'is_trending', 'is_editors_pick', 'is_video'];
        if (!in_array($flag, $allowed, true)) {
            return [];
        }
        $stmt = Database::connection()->prepare(self::select() . ' WHERE ' . self::publishedWhere() . " AND a.{$flag} = 1 ORDER BY a.published_at DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function mostRead(int $limit = 8): array
    {
        $stmt = Database::connection()->prepare(self::select() . ' WHERE ' . self::publishedWhere() . ' ORDER BY a.views_count DESC, a.published_at DESC LIMIT :limit');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function find(string $categorySlug, string $slug): ?array
    {
        $sql = self::select() . ' WHERE ' . self::publishedWhere() . ' AND c.slug = :category AND a.slug = :slug LIMIT 1';
        $stmt = Database::connection()->prepare($sql);
        $stmt->execute(['category' => $categorySlug, 'slug' => $slug]);
        $article = $stmt->fetch();
        if (!$article) {
            return null;
        }
        $tagStmt = Database::connection()->prepare('SELECT t.name, t.slug FROM tags t JOIN article_tags at ON at.tag_id = t.id WHERE at.article_id = ? ORDER BY t.name');
        $tagStmt->execute([$article['id']]);
        $article['tags'] = $tagStmt->fetchAll();
        return $article;
    }

    public static function related(array $article, int $limit = 4): array
    {
        $stmt = Database::connection()->prepare(self::select() . ' WHERE ' . self::publishedWhere() . ' AND a.category_id = :category AND a.id <> :id ORDER BY a.published_at DESC LIMIT :limit');
        $stmt->bindValue(':category', (int) $article['category_id'], PDO::PARAM_INT);
        $stmt->bindValue(':id', (int) $article['id'], PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function search(array $filters, int $page = 1, int $perPage = 10): array
    {
        $where = [self::publishedWhere()];
        $params = [];
        if ($filters['q'] ?? '') {
    $where[] = '(a.title LIKE :q_title OR a.subtitle LIKE :q_subtitle OR a.body LIKE :q_body)';

    $searchTerm = '%' . trim($filters['q']) . '%';

    $params['q_title'] = $searchTerm;
    $params['q_subtitle'] = $searchTerm;
    $params['q_body'] = $searchTerm;
        }
        if ($filters['category'] ?? '') {
            $where[] = 'c.slug = :category';
            $params['category'] = $filters['category'];
        }
        if ($filters['author'] ?? '') {
            $where[] = 'u.slug = :author';
            $params['author'] = $filters['author'];
        }
        if ($filters['date'] ?? '') {
            $where[] = 'DATE(a.published_at) = :date';
            $params['date'] = $filters['date'];
        }
        if ($filters['tag'] ?? '') {
            $where[] = 'EXISTS (SELECT 1 FROM article_tags sat JOIN tags st ON st.id = sat.tag_id WHERE sat.article_id = a.id AND st.slug = :tag)';
            $params['tag'] = $filters['tag'];
        }
        $pdo = Database::connection();
        $count = $pdo->prepare('SELECT COUNT(*) FROM articles a JOIN categories c ON c.id = a.category_id JOIN users u ON u.id = a.author_id WHERE ' . implode(' AND ', $where));
        $count->execute($params);
        $total = (int) $count->fetchColumn();
        $stmt = $pdo->prepare(self::select() . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY a.published_at DESC LIMIT :limit OFFSET :offset');
        foreach ($params as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', max(0, ($page - 1) * $perPage), PDO::PARAM_INT);
        $stmt->execute();
        return ['items' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'pages' => max(1, (int) ceil($total / $perPage))];
    }

    public static function incrementView(int $id): void
    {
        Database::transaction(static function (PDO $pdo) use ($id): void {
            $pdo->prepare('UPDATE articles SET views_count = views_count + 1 WHERE id = ?')->execute([$id]);
            $pdo->prepare('INSERT INTO article_views (article_id, session_hash, ip_hash, viewed_at) VALUES (?, ?, ?, NOW())')->execute([
                $id,
                hash('sha256', session_id()),
                hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . config('app.key')),
            ]);
        });
    }

    public static function adjacent(array $article): array
    {
        $pdo = Database::connection();
        $previous = $pdo->prepare(self::select() . ' WHERE ' . self::publishedWhere() . ' AND a.published_at < ? ORDER BY a.published_at DESC LIMIT 1');
        $previous->execute([$article['published_at']]);
        $next = $pdo->prepare(self::select() . ' WHERE ' . self::publishedWhere() . ' AND a.published_at > ? ORDER BY a.published_at ASC LIMIT 1');
        $next->execute([$article['published_at']]);
        return ['previous' => $previous->fetch() ?: null, 'next' => $next->fetch() ?: null];
    }
}
