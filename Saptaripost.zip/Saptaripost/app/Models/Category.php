<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Category
{
    public static function all(bool $parentsOnly = false): array
    {
        $sql = 'SELECT c.*, p.name AS parent_name FROM categories c LEFT JOIN categories p ON p.id = c.parent_id WHERE c.is_active = 1';
        if ($parentsOnly) {
            $sql .= ' AND c.parent_id IS NULL';
        }
        return Database::connection()->query($sql . ' ORDER BY c.display_order, c.name')->fetchAll();
    }

    public static function find(string $slug): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM categories WHERE slug = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$slug]);
        return $stmt->fetch() ?: null;
    }

    public static function children(int $parentId): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM categories WHERE parent_id = ? AND is_active = 1 ORDER BY display_order, name');
        $stmt->execute([$parentId]);
        return $stmt->fetchAll();
    }
}
