<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDOException;

final class User
{
    public static function register(array $data): int
    {
        $pdo = Database::connection();
        $roleId = (int) $pdo->query("SELECT id FROM roles WHERE slug = 'registered-reader' LIMIT 1")->fetchColumn();
        $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($data['name'])), '-');
        try {
            $stmt = $pdo->prepare('INSERT INTO users (role_id, name, slug, email, password_hash, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, "active", NOW(), NOW())');
            $stmt->execute([$roleId, $data['name'], $slug . '-' . bin2hex(random_bytes(2)), mb_strtolower($data['email']), password_hash($data['password'], PASSWORD_DEFAULT)]);
        } catch (PDOException $e) {
            if ((int) $e->errorInfo[1] === 1062) {
                throw new \InvalidArgumentException('An account with this email already exists.');
            }
            throw $e;
        }
        return (int) $pdo->lastInsertId();
    }

    public static function authors(): array
    {
        return Database::connection()->query("SELECT u.id, u.name, u.slug, u.bio, u.avatar, r.name AS role_name, COUNT(a.id) AS article_count FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN articles a ON a.author_id = u.id AND a.status = 'published' AND a.deleted_at IS NULL WHERE r.slug IN ('super-administrator','administrator','editor','reporter','contributor') AND u.status = 'active' GROUP BY u.id ORDER BY u.name")->fetchAll();
    }

    public static function author(string $slug): ?array
    {
        $stmt = Database::connection()->prepare('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.slug = ? AND u.status = "active" LIMIT 1');
        $stmt->execute([$slug]);
        return $stmt->fetch() ?: null;
    }
}
