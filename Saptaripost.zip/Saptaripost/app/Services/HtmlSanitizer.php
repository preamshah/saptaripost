<?php

declare(strict_types=1);

namespace App\Services;

use DOMDocument;

final class HtmlSanitizer
{
    public static function clean(string $html): string
    {
        $allowed = '<p><br><h2><h3><h4><ul><ol><li><a><strong><em><blockquote><figure><figcaption><img><table><thead><tbody><tr><th><td><iframe>';
        $html = strip_tags($html, $allowed);
        if (!class_exists(DOMDocument::class)) {
            $html = preg_replace('/\s(on\w+|style)\s*=\s*(["\']).*?\2/iu', '', $html) ?? '';
            return preg_replace('/\s(href|src)\s*=\s*(["\'])\s*(javascript|data):.*?\2/iu', '', $html) ?? '';
        }
        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8" ?><div id="root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        foreach ($dom->getElementsByTagName('*') as $element) {
            $remove = [];
            foreach ($element->attributes ?? [] as $attribute) {
                $name = strtolower($attribute->name);
                $value = trim($attribute->value);
                if (str_starts_with($name, 'on') || $name === 'style') {
                    $remove[] = $name;
                    continue;
                }
                if (in_array($name, ['href', 'src'], true) && preg_match('/^(javascript|data):/i', $value)) {
                    $remove[] = $name;
                }
                if (!in_array($name, ['href', 'src', 'alt', 'title', 'width', 'height', 'loading', 'allowfullscreen', 'frameborder'], true)) {
                    $remove[] = $name;
                }
            }
            foreach ($remove as $name) {
                $element->removeAttribute($name);
            }
            if ($element->tagName === 'iframe') {
                $src = $element->getAttribute('src');
                if (!preg_match('#^https://(www\.)?youtube(-nocookie)?\.com/embed/#i', $src)) {
                    $element->parentNode?->removeChild($element);
                }
            }
        }
        $root = $dom->getElementById('root');
        $output = '';
        foreach ($root?->childNodes ?? [] as $child) {
            $output .= $dom->saveHTML($child);
        }
        return $output;
    }
}
