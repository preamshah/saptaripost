<?php

declare(strict_types=1);

namespace App\Services;

use RuntimeException;

final class UploadService
{
    public static function image(array $file): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Choose an image to upload.');
        }
        $max = (int) config('app.upload_max_mb', 5) * 1024 * 1024;
        if (($file['size'] ?? 0) > $max) {
            throw new RuntimeException('The image exceeds the upload size limit.');
        }
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        if (!isset($map[$mime]) || !getimagesize($file['tmp_name'])) {
            throw new RuntimeException('Only valid JPG, PNG, WebP, and GIF images are accepted.');
        }
        $name = date('Y/m');
        $directory = BASE_PATH . '/public/uploads/' . $name;
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new RuntimeException('Upload directory is not writable.');
        }
        $filename = bin2hex(random_bytes(18)) . '.' . $map[$mime];
        if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
            throw new RuntimeException('The upload could not be saved.');
        }
        [$width, $height] = getimagesize($directory . '/' . $filename);
        return ['path' => 'uploads/' . $name . '/' . $filename, 'mime' => $mime, 'size' => $file['size'], 'width' => $width, 'height' => $height, 'original_name' => basename($file['name'])];
    }
}
