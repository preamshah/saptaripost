<?php
$formData = $article ?? [];

$value = static fn(string $key, string $default = ''): string => e((string) ($formData[$key] ?? $default));
$selected = static fn(string $key, string|int $expected, string|int $default = ''): string =>
    (string) ($formData[$key] ?? $default) === (string) $expected ? 'selected' : '';
$isChecked = static fn(string $key, bool $default = false): string =>
    ($article[$key] ?? $default) ? 'checked' : '';
?>

<div class="admin-heading">
    <div><span>Story editor</span><h1><?= $article ? 'Edit Article' : 'New Article' ?></h1></div>
    <div class="heading-actions">
        <a class="secondary-button" href="<?= e(url('/admin/articles')) ?>">Back to articles</a>
        <?php if ($article && $article['status'] === 'published'): ?>
            <a class="secondary-button" target="_blank" href="<?= e(url('/news/' . ($article['category_slug'] ?? '') . '/' . $article['slug'])) ?>">Preview</a>
        <?php endif; ?>
    </div>
</div>

<form method="post" action="<?= e(url('/admin/articles/' . ($article ? $article['id'] : 'new'))) ?>" class="editor-layout" id="articleEditor">
    <?= csrf_field() ?>
    <div class="editor-main admin-card">
        <label>Headline<input name="title" value="<?= $value('title') ?>" minlength="8" required data-slug-source></label>
        <label>Subtitle<input name="subtitle" value="<?= $value('subtitle') ?>"></label>

        <div class="form-row">
            <label>
                Category
                <select name="category_id" required>
                    <option value="">Choose category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= (int) $category['id'] ?>" <?= $selected('category_id', (int) $category['id']) ?>>
                            <?= e(($category['parent_name'] ? $category['parent_name'] . ' › ' : '') . $category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Slug<input name="slug" value="<?= $value('slug') ?>" pattern="[a-z0-9-]+" data-slug-target></label>
        </div>

        <label>Short excerpt<textarea name="excerpt" rows="3" maxlength="350"><?= $value('excerpt') ?></textarea></label>
        <label>
            Article body
            <small>Write the complete article in plain text.</small>
            <textarea name="body" rows="24" required data-autosave><?= $value('body') ?></textarea>
        </label>

        <div class="form-row">
            <label>Featured image path<input name="featured_image" value="<?= $value('featured_image', 'assets/images/news-placeholder.svg') ?>"></label>
            <label>Image alt text<input name="image_alt" value="<?= $value('image_alt') ?>"></label>
        </div>
        <div class="form-row">
            <label>Image caption<input name="image_caption" value="<?= $value('image_caption') ?>"></label>
            <label>Image credit/source<input name="image_credit" value="<?= $value('image_credit') ?>"></label>
        </div>
    </div>

    <aside class="editor-sidebar">
        <section class="admin-card">
            <h2>Publish</h2>
            <label>
                Status
                <select name="status">
                    <option value="draft" <?= $selected('status', 'draft', 'draft') ?>>Draft</option>
                    <option value="pending_review" <?= $selected('status', 'pending_review') ?>>Pending review</option>
                    <option value="scheduled" <?= $selected('status', 'scheduled') ?>>Scheduled</option>
                    <?php if (can('articles.publish')): ?>
                        <option value="published" <?= $selected('status', 'published') ?>>Published</option>
                        <option value="rejected" <?= $selected('status', 'rejected') ?>>Rejected</option>
                    <?php endif; ?>
                </select>
            </label>
            <label>
                Publish date/time
                <input type="datetime-local" name="published_at" value="<?= !empty($formData['published_at']) ? e(date('Y-m-d\TH:i', strtotime((string) $formData['published_at']))) : '' ?>">
            </label>
            <button class="primary-button full" type="submit">Save article</button>
            <small id="autosaveStatus">Local draft autosave ready.</small>
        </section>

        <section class="admin-card">
            <h2>Story flags</h2>
            <?php foreach (['is_featured' => 'Featured', 'is_breaking' => 'Breaking news', 'is_trending' => 'Trending', 'is_editors_pick' => "Editor's pick", 'is_exclusive' => 'Exclusive', 'is_live' => 'Live updates', 'is_video' => 'Video news', 'allow_comments' => 'Allow comments'] as $key => $label): ?>
                <label class="checkbox">
                    <input type="checkbox" name="<?= e($key) ?>" value="1" <?= $isChecked($key, $key === 'allow_comments') ?>>
                    <span><?= e($label) ?></span>
                </label>
            <?php endforeach; ?>
        </section>

        <section class="admin-card">
            <h2>SEO</h2>
            <label>SEO title<input name="seo_title" value="<?= $value('seo_title') ?>" maxlength="70"></label>
            <label>Meta description<textarea name="meta_description" rows="4" maxlength="170"><?= $value('meta_description') ?></textarea></label>
            <label>Focus keyword<input name="focus_keyword" value="<?= $value('focus_keyword') ?>"></label>
            <label>Canonical URL<input type="url" name="canonical_url" value="<?= $value('canonical_url') ?>"></label>
        </section>
    </aside>
</form>
