<article class="article-page" data-article>

    <header class="container article-header">

        <nav class="breadcrumbs" aria-label="Breadcrumb">
            <a href="<?= e(url('/')) ?>">Home</a>
            <span>/</span>
            <a href="<?= e(url('/category/' . $article['category_slug'])) ?>">
                <?= e($article['category_name']) ?>
            </a>
        </nav>

        <div class="article-labels">
            <?php if ($article['is_breaking']): ?>
                <span>Breaking</span>
            <?php endif; ?>

            <?php if ($article['is_exclusive']): ?>
                <span>Exclusive</span>
            <?php endif; ?>

            <?php if ($article['is_live']): ?>
                <span>Live</span>
            <?php endif; ?>
        </div>

        <h1><?= e($article['title']) ?></h1>

        <?php if ($article['subtitle']): ?>
            <p class="article-deck">
                <?= e($article['subtitle']) ?>
            </p>
        <?php endif; ?>

        <div class="article-byline">

            <a href="<?= e(url('/author/' . $article['author_slug'])) ?>">
                <?= e($article['author_name']) ?>
            </a>

            <span>
                Published
                <time datetime="<?= e(date(DATE_ATOM, strtotime($article['published_at']))) ?>">
                    <?= e(date('F j, Y · H:i', strtotime($article['published_at']))) ?>
                </time>
            </span>

            <span>
                Updated
                <?= e(date('M j, H:i', strtotime($article['updated_at']))) ?>
            </span>

            <span>
                <?= reading_time($article['body']) ?> min read
            </span>

            <span>
                <?= number_format((int) $article['views_count'] + 1) ?> views
            </span>

        </div>

        <div class="article-tools">

            <button
                type="button"
                data-font="decrease"
                aria-label="Decrease article font size"
            >
                A−
            </button>

            <button
                type="button"
                data-font="increase"
                aria-label="Increase article font size"
            >
                A+
            </button>

            <button
                type="button"
                onclick="window.print()"
            >
                Print
            </button>

            <button
                type="button"
                data-copy-link
            >
                Copy link
            </button>

            <button
                type="button"
                data-native-share
            >
                Share
            </button>

        </div>

    </header>


    <!-- Above Article Advertisement -->
    <div class="container">
        <?php
        $ad = $aboveAd;
        require dirname(__DIR__) . '/partials/ad.php';
        ?>
    </div>


    <!-- Featured Image -->
    <figure class="container article-figure">

        <img
            src="<?= e(url('/' . $article['featured_image'])) ?>"
            alt="<?= e($article['image_alt'] ?: $article['title']) ?>"
            width="1280"
            height="720"
        >

        <figcaption>

            <?= e($article['image_caption']) ?>

            <?php if ($article['image_credit']): ?>
                <span>
                    Credit: <?= e($article['image_credit']) ?>
                </span>
            <?php endif; ?>

        </figcaption>

    </figure>


    <!-- Main Article Layout -->
    <div class="container article-layout">

        <div
            class="article-content"
            id="articleBody"
        >
            <?= nl2br(e($article['body'])) ?>

            <?php
            $ad = $insideAd;
            require dirname(__DIR__) . '/partials/ad.php';
            ?>
        </div>


        <!-- Article Sidebar -->
        <aside class="article-sidebar">

            <div class="share-panel">

                <strong>Share this story</strong>

                <a
                    target="_blank"
                    rel="noopener"
                    href="https://www.facebook.com/sharer/sharer.php?u=<?= rawurlencode($canonical) ?>"
                >
                    Facebook
                </a>

                <a
                    target="_blank"
                    rel="noopener"
                    href="https://twitter.com/intent/tweet?url=<?= rawurlencode($canonical) ?>&text=<?= rawurlencode($article['title']) ?>"
                >
                    X
                </a>

                <a
                    target="_blank"
                    rel="noopener"
                    href="https://wa.me/?text=<?= rawurlencode($article['title'] . ' ' . $canonical) ?>"
                >
                    WhatsApp
                </a>

                <a
                    target="_blank"
                    rel="noopener"
                    href="https://www.linkedin.com/sharing/share-offsite/?url=<?= rawurlencode($canonical) ?>"
                >
                    LinkedIn
                </a>

                <a
                    target="_blank"
                    rel="noopener"
                    href="https://t.me/share/url?url=<?= rawurlencode($canonical) ?>"
                >
                    Telegram
                </a>

            </div>

        </aside>

    </div>


    <!-- After Article Content -->
    <div class="container article-after">

        <?php
        $ad = $belowAd;
        require dirname(__DIR__) . '/partials/ad.php';
        ?>


        <!-- Tags -->
        <div class="tag-list">

            <?php foreach ($article['tags'] as $tag): ?>

                <a href="<?= e(url('/tag/' . $tag['slug'])) ?>">
                    #<?= e($tag['name']) ?>
                </a>

            <?php endforeach; ?>

        </div>


        <!-- Author Box -->
        <div class="author-box">

            <div>

                <strong>
                    About <?= e($article['author_name']) ?>
                </strong>

                <p>
                    Saptari Post newsroom contributor.
                    Visit the author profile for biography and recent reporting.
                </p>

            </div>

            <a href="<?= e(url('/author/' . $article['author_slug'])) ?>">
                View profile
            </a>

        </div>


        <!-- Reactions -->
        <div class="reactions">

            <strong>
                How did this story make you feel?
            </strong>

            <?php
            foreach (
                [
                    'like'       => 'Useful',
                    'love'       => 'Important',
                    'insightful' => 'Insightful',
                    'concerned'  => 'Concerned',
                ] as $type => $label
            ):
            ?>

                <form
                    method="post"
                    action="<?= e(url('/article/' . $article['id'] . '/react')) ?>"
                >
                    <?= csrf_field() ?>

                    <input
                        type="hidden"
                        name="type"
                        value="<?= e($type) ?>"
                    >

                    <button type="submit">
                        <?= e($label) ?>
                    </button>

                </form>

            <?php endforeach; ?>


            <?php if (user()): ?>

                <form
                    method="post"
                    action="<?= e(url('/article/' . $article['id'] . '/bookmark')) ?>"
                >
                    <?= csrf_field() ?>

                    <button type="submit">
                        Save article
                    </button>

                </form>

            <?php endif; ?>

        </div>


        <!-- Previous / Next Article -->
        <nav
            class="article-adjacent"
            aria-label="Previous and next articles"
        >

            <?php if ($adjacent['previous']): ?>

                <a
                    href="<?= e(
                        url(
                            '/news/' .
                            $adjacent['previous']['category_slug'] .
                            '/' .
                            $adjacent['previous']['slug']
                        )
                    ) ?>"
                >
                    <span>Previous story</span>

                    <strong>
                        <?= e($adjacent['previous']['title']) ?>
                    </strong>
                </a>

            <?php endif; ?>


            <?php if ($adjacent['next']): ?>

                <a
                    href="<?= e(
                        url(
                            '/news/' .
                            $adjacent['next']['category_slug'] .
                            '/' .
                            $adjacent['next']['slug']
                        )
                    ) ?>"
                >
                    <span>Next story</span>

                    <strong>
                        <?= e($adjacent['next']['title']) ?>
                    </strong>
                </a>

            <?php endif; ?>

        </nav>


        <!-- Related News -->
        <section class="related-news">

            <div class="section-heading">
                <h2>Related News</h2>
            </div>

            <div class="horizontal-grid">

                <?php
                foreach ($related as $item) {
                    require dirname(__DIR__) . '/partials/article-card.php';
                }
                ?>

            </div>

        </section>


        <!-- Comments -->
        <?php if ($article['allow_comments']): ?>

            <section class="comments">

                <h2>Comments</h2>

                <p>
                    Comments are moderated according to our
                    <a href="<?= e(url('/community-guidelines')) ?>">
                        community guidelines
                    </a>.
                </p>


                <form
                    method="post"
                    action="<?= e(url('/article/' . $article['id'] . '/comment')) ?>"
                    class="stacked-form"
                >

                    <?= csrf_field() ?>


                    <div class="form-row">

                        <label>
                            Name

                            <input
                                name="name"
                                value="<?= e(user()['name'] ?? '') ?>"
                                required
                            >
                        </label>


                        <label>
                            Email

                            <input
                                type="email"
                                name="email"
                                value="<?= e(user()['email'] ?? '') ?>"
                                required
                            >
                        </label>

                    </div>


                    <label>
                        Comment

                        <textarea
                            name="body"
                            rows="5"
                            minlength="3"
                            maxlength="2000"
                            required
                        ></textarea>
                    </label>


                    <button type="submit">
                        Submit for review
                    </button>

                </form>


                <!-- Comment List -->
                <div class="comment-list">

                    <?php foreach ($comments as $comment): ?>

                        <article>

                            <strong>
                                <?= e(
                                    $comment['commenter_name']
                                    ?: $comment['guest_name']
                                ) ?>
                            </strong>

                            <time>
                                <?= e(
                                    date(
                                        'M j, Y',
                                        strtotime($comment['created_at'])
                                    )
                                ) ?>
                            </time>

                            <p>
                                <?= nl2br(e($comment['body'])) ?>
                            </p>

                        </article>

                    <?php endforeach; ?>

                </div>

            </section>

        <?php endif; ?>


        <!-- Correction Request -->
        <p class="correction-link">
            See something wrong?

            <a
                href="<?= e(
                    url(
                        '/correction-request?article=' .
                        rawurlencode($canonical)
                    )
                ) ?>"
            >
                Request a correction
            </a>.
        </p>

    </div>


    <!-- Mobile Share Bar -->
    <div class="mobile-share-bar">

        <button
            type="button"
            data-native-share
        >
            Share
        </button>

        <button
            type="button"
            data-copy-link
        >
            Copy link
        </button>

    </div>

</article>