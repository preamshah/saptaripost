<section class="error-page"><strong>403</strong><h1>Access denied</h1><p>You do not have permission to open this area.</p><a href="<?= e(url('/')) ?>">Return to homepage</a></section>
