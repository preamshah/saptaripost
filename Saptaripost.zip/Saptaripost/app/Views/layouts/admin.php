<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
    <title><?= e($title ?? 'Admin') ?> — Saptari Post</title>
    <link rel="icon" href="<?= e(asset('icons/favicon-Saptripost.svg')) ?>" type="image/svg+xml">
    <link rel="stylesheet" href="<?= e(asset('css/app.css?v=20260830-1')) ?>">
</head>
<body class="admin-body">
<a class="skip-link" href="#adminContent">Skip to content</a>
<aside class="admin-sidebar" id="adminSidebar">
    <a class="admin-brand" href="<?= e(url('/admin')) ?>"><img src="<?= e(asset('images/Saptaripost-logo.svg')) ?>" alt="Saptari Post" width="190" height="50"></a>
    <nav aria-label="Admin">
        <?php if ((user()['role_slug'] ?? '') === 'editor'): ?>
            <a href="<?= e(url('/admin/articles')) ?>">Articles</a>
            <a href="<?= e(url('/admin/media')) ?>">Media</a>
        <?php else: ?>
            <a href="<?= e(url('/admin')) ?>">Dashboard</a>
            <a href="<?= e(url('/admin/articles')) ?>">Articles</a>
            <a href="<?= e(url('/admin/media')) ?>">Media</a>
            <a href="<?= e(url('/admin/categories')) ?>">Categories</a>
            <a href="<?= e(url('/admin/module/tags')) ?>">Tags</a>
            <a href="<?= e(url('/admin/comments')) ?>">Comments</a>
            <a href="<?= e(url('/admin/module/users')) ?>">Users & Roles</a>
            <a href="<?= e(url('/admin/ads')) ?>">Advertisements</a>
            <a href="<?= e(url('/admin/module/homepage')) ?>">Homepage Sections</a>
            <a href="<?= e(url('/admin/module/menus')) ?>">Menus</a>
            <a href="<?= e(url('/admin/module/polls')) ?>">Polls</a>
            <a href="<?= e(url('/admin/module/galleries')) ?>">Galleries</a>
            <a href="<?= e(url('/admin/module/messages')) ?>">Messages</a>
            <a href="<?= e(url('/admin/module/subscribers')) ?>">Subscribers</a>
            <a href="<?= e(url('/admin/module/redirects')) ?>">Redirects</a>
            <a href="<?= e(url('/admin/module/activity')) ?>">Activity Logs</a>
            <a href="<?= e(url('/admin/change-password')) ?>">Change Password</a>
            <a href="<?= e(url('/admin/settings')) ?>">Settings & SEO</a>
        <?php endif; ?>
    </nav>
</aside>
<div class="admin-shell">
    <header class="admin-topbar"><button type="button" id="adminMenu" class="icon-button" aria-label="Toggle admin menu">☰</button><strong><?= e($title ?? 'Admin') ?></strong><div><?php if ((user()['role_slug'] ?? '') !== 'editor'): ?><a href="<?= e(url('/')) ?>" target="_blank" rel="noopener">View site</a><?php endif; ?><span><?= e(user()['name'] ?? '') ?></span><form action="<?= e(url('/logout')) ?>" method="post" class="inline-form"><?= csrf_field() ?><button type="submit" class="link-button">Sign out</button></form></div></header>
    <?php if ($success = flash('success')): ?><div class="alert success" role="status"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error = flash('error')): ?><div class="alert error" role="alert"><?= e($error) ?></div><?php endif; ?>
    <main id="adminContent" class="admin-content"><?= $content ?></main>
</div>
<script src="<?= e(asset('js/admin.js')) ?>" defer></script>
</body></html>
