<?php
use App\Models\Category;
$siteName = config('app.name', 'Saptari Post');
$title = $title ?? $siteName;
$metaDescription = $metaDescription ?? 'Independent Nepal news, insight and context.';
$canonical = $canonical ?? url(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$robots = $robots ?? 'index,follow,max-image-preview:large';
$locale = $_SESSION['locale'] ?? config('app.locale', 'en');
try { $navCategories = Category::all(true); } catch (Throwable) { $navCategories = []; }
?>
<!doctype html>
<html lang="<?= e($locale === 'ne' ? 'ne-NP' : 'en-NP') ?>" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#a4101b">
    <title><?= e($title) ?></title>
    <meta name="description" content="<?= e($metaDescription) ?>">
    <meta name="robots" content="<?= e($robots) ?>">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <meta property="og:type" content="<?= isset($article) ? 'article' : 'website' ?>">
    <meta property="og:site_name" content="Saptari Post">
    <meta property="og:title" content="<?= e($title) ?>">
    <meta property="og:description" content="<?= e($metaDescription) ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <meta property="og:image" content="<?= e(isset($article) ? url('/' . $article['featured_image']) : asset('images/social-card.svg')) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <?php if (env('GOOGLE_SITE_VERIFICATION')): ?><meta name="google-site-verification" content="<?= e(env('GOOGLE_SITE_VERIFICATION')) ?>"><?php endif; ?>
    <?php if (env('BING_SITE_VERIFICATION')): ?><meta name="msvalidate.01" content="<?= e(env('BING_SITE_VERIFICATION')) ?>"><?php endif; ?>
    <link rel="icon" href="<?= e(asset('icons/favicon-Saptripost.svg')) ?>" type="image/svg+xml">
    <link rel="alternate" type="application/rss+xml" title="Saptari Post RSS" href="<?= e(url('/rss.xml')) ?>">
    <link rel="preload" href="<?= e(asset('css/app.css')) ?>" as="style">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= e(asset('css/app.css?v=20260830-3')) ?>">
    <script type="application/ld+json"><?= json_encode([
        '@context' => 'https://schema.org', '@type' => 'NewsMediaOrganization', 'name' => 'Saptari Post',
        'url' => url(), 'logo' => asset('images/Saptaripost-logo.svg'), 'email' => 'info@saptaripost.com',
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
    <?php if (isset($article)): ?>
    <script type="application/ld+json"><?= json_encode([
        '@context' => 'https://schema.org', '@type' => 'NewsArticle', 'headline' => $article['title'],
        'description' => $article['meta_description'] ?: excerpt($article['body']), 'image' => [url('/' . $article['featured_image'])],
        'datePublished' => date(DATE_ATOM, strtotime($article['published_at'])), 'dateModified' => date(DATE_ATOM, strtotime($article['updated_at'])),
        'author' => ['@type' => 'Person', 'name' => $article['author_name'], 'url' => url('/author/' . $article['author_slug'])],
        'publisher' => ['@type' => 'NewsMediaOrganization', 'name' => 'Saptari Post', 'logo' => ['@type' => 'ImageObject', 'url' => asset('images/Saptaripost-logo.svg')]],
        'mainEntityOfPage' => $canonical,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
    <?php endif; ?>
</head>
<body>
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="reading-progress" id="readingProgress" aria-hidden="true"></div>
<header class="site-header">
    <div class="topbar">
        <div class="container topbar-inner">
            <span><?= e(date('l, F j, Y')) ?></span>
            <span lang="ne">Kathmandu Time: <?= e(date('H:i')) ?></span>
            <div class="topbar-links"><a href="<?= e(url('/about-us')) ?>">About</a><a href="<?= e(url('/contact')) ?>">Contact</a><a href="?lang=<?= $locale === 'en' ? 'ne' : 'en' ?>" lang="<?= $locale === 'en' ? 'ne' : 'en' ?>"><?= $locale === 'en' ? 'नेपाली' : 'English' ?></a></div>
        </div>
    </div>
    <div class="container brand-row">
        <a class="brand" href="<?= e(url('/')) ?>" aria-label="Saptari Post home"><img src="<?= e(asset('images/Saptaripost-logo.svg')) ?>" width="260" height="68" alt="Saptari Post"></a>
        <div class="header-actions">
            <button class="icon-button" id="themeToggle" type="button" aria-label="Toggle dark mode">◐</button>
            <button class="icon-button" id="searchToggle" type="button" aria-label="Open search">⌕</button>
            <?php if (user()): ?><a class="account-link" href="<?= e(url(user()['role_slug'] === 'registered-reader' ? '/reader' : '/admin')) ?>"><?= e(user()['name']) ?></a><?php else: ?><a class="account-link" href="<?= e(url('/login')) ?>">Sign in</a><?php endif; ?>
        </div>
    </div>
    <div class="search-panel" id="searchPanel" hidden>
        <form class="container search-form" action="<?= e(url('/search')) ?>" method="get" role="search">
            <label class="visually-hidden" for="globalSearch">Search news</label>
            <input id="globalSearch" name="q" type="search" placeholder="Search Nepal news…" autocomplete="off" data-suggestions="<?= e(url('/api/search-suggestions')) ?>">
            <button type="submit">Search</button>
            <div class="suggestions" id="searchSuggestions"></div>
        </form>
    </div>
    <nav class="main-nav" aria-label="Primary navigation">
        <div class="container nav-inner">
            <button class="menu-toggle" id="menuToggle" type="button" aria-expanded="false" aria-controls="primaryMenu">☰ <span>Menu</span></button>
            <ul id="primaryMenu">
                <li><a href="<?= e(url('/')) ?>">Home</a></li>
                <?php foreach (array_slice($navCategories, 0, 9) as $category): ?><li><a href="<?= e(url('/category/' . $category['slug'])) ?>"><?= e($locale === 'ne' && $category['name_ne'] ? $category['name_ne'] : $category['name']) ?></a></li><?php endforeach; ?>
                <li><a href="<?= e(url('/latest')) ?>">Latest</a></li>
            </ul>
        </div>
    </nav>
</header>

<?php if ($success = flash('success')): ?><div class="container alert alert-success mt-3" role="status"><?= e($success) ?></div><?php endif; ?>
<?php if ($error = flash('error')): ?><div class="container alert alert-danger mt-3" role="alert"><?= e($error) ?></div><?php endif; ?>
<?php if ($info = flash('info')): ?><div class="container alert alert-info mt-3" role="status"><?= e($info) ?></div><?php endif; ?>

<main id="main-content" tabindex="-1"><?= $content ?></main>

<footer class="site-footer">
    <div class="container footer-grid">
        <div><img src="<?= e(asset('images/Saptaripost-logo.svg')) ?>" width="220" height="58" alt="Saptari Post"><p>An Independent words from ground zero to public.</p><p><strong>The Saptari Post</strong> is an independent digital news platform delivering accurate, timely, and reliable news from Saptari, Nepal, and around the world.</p></div>
        <div><h2>News</h2><a href="<?= e(url('/latest')) ?>">Latest News</a><a href="<?= e(url('/trending')) ?>">Trending</a><a href="<?= e(url('/video-news')) ?>">Video News</a><a href="<?= e(url('/photo-gallery')) ?>">Photo Gallery</a><a href="<?= e(url('/authors')) ?>">Our Team</a></div>
        <div><h2>Policies</h2><a href="<?= e(url('/editorial-policy')) ?>">Editorial Policy</a><a href="<?= e(url('/corrections-policy')) ?>">Corrections Policy</a><a href="<?= e(url('/privacy-policy')) ?>">Privacy Policy</a><a href="<?= e(url('/terms-and-conditions')) ?>">Terms</a><a href="<?= e(url('/ownership-funding-disclosure')) ?>">Ownership & Funding</a></div>
        <div><h2>Connect</h2><a href="<?= e(url('/contact')) ?>">Contact Us</a><a href="<?= e(url('/advertise-with-us')) ?>">Advertise With Us</a><a href="<?= e(url('/submit-news-tip')) ?>">Submit News Tip</a><a href="<?= e(url('/rss.xml')) ?>">RSS Feed</a><a href="mailto:info@saptaripost.com">info@saptaripost.com</a></div>
    </div>
    
    <div class="container footer-bottom">
    <span>© <?= date('Y') ?> Saptari Post. All rights reserved.</span>
    <span>
        Designed & Developed By 
        <a href="https://preamshah.com/" target="_blank" rel="noopener noreferrer">
            Pream Shah
        </a>
    </span>
</div>
    
</footer>
<button class="back-to-top" id="backToTop" aria-label="Back to top">↑</button>
<div class="cookie-banner" id="cookieBanner" hidden><p>We use essential cookies for security and preferences. Analytics and advertising remain disabled until configured.</p><button type="button" data-cookie-accept>Accept essential</button><a href="<?= e(url('/cookie-policy')) ?>">Cookie policy</a></div>
<script>window.APP_BASE=<?= json_encode(url(), JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous" defer></script>
<script src="<?= e(asset('js/app.js?v=20260830-2')) ?>" defer></script>
</body>
</html>
