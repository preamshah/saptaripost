<?php if (!empty($ad)): ?>
<aside class="ad-slot" aria-label="Advertisement"><span>Advertisement</span>
    <?php if ($ad['ad_type'] === 'image' && $ad['image_path']): ?><a href="<?= e(url('/ad/click/' . $ad['id'])) ?>" rel="sponsored nofollow"><img src="<?= e(url('/' . $ad['image_path'])) ?>" alt="<?= e($ad['name']) ?>" loading="lazy"></a>
    <?php elseif ($ad['ad_type'] === 'code'): ?><?= $ad['ad_code'] ?>
    <?php else: ?><div class="ad-placeholder">Reserved ad space</div><?php endif; ?>
</aside>
<?php else: ?><aside class="ad-slot ad-placeholder" aria-label="Advertisement placeholder"><span>Advertisement</span><strong>Responsive ad placement</strong></aside><?php endif; ?>
