<article class="news-card">
    <a class="card-image" href="<?= e(url('/news/' . $item['category_slug'] . '/' . $item['slug'])) ?>">
        <img src="<?= e(url('/' . ($item['featured_image'] ?: 'assets/images/news-placeholder.svg'))) ?>" alt="<?= e($item['image_alt'] ?: $item['title']) ?>" width="640" height="360" loading="lazy">
    </a>
    <div class="card-body">
        <a class="category-label" href="<?= e(url('/category/' . $item['category_slug'])) ?>"><?= e($item['category_name']) ?></a>
        <h3><a href="<?= e(url('/news/' . $item['category_slug'] . '/' . $item['slug'])) ?>"><?= e($item['title']) ?></a></h3>
        <?php if (!empty($showExcerpt)): ?><p><?= e($item['excerpt'] ?: excerpt($item['body'], 120)) ?></p><?php endif; ?>
        <div class="story-meta"><span><?= e($item['author_name'] ?? 'Saptari Post') ?></span><time datetime="<?= e(date(DATE_ATOM, strtotime($item['published_at']))) ?>"><?= e(date('M j, Y', strtotime($item['published_at']))) ?></time></div>
    </div>
</article>
