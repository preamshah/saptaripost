<section class="container reader-page">
    <header class="archive-header">
        <span>Reader space</span>

        <h1>
            Hello, <?= e(user()['name']) ?>
        </h1>

        <p>
            Your saved stories are linked to your account.
            Recent reading history is stored only in this browser session.
        </p>
    </header>

    <div class="section-heading">
        <h2>Saved articles</h2>
    </div>

    <div class="news-grid">
        <?php foreach ($bookmarks as $item): ?>
            <div>
                <?php
                require dirname(__DIR__) . '/partials/article-card.php';
                ?>

                <form
                    method="post"
                    action="<?= e(url('/reader/bookmark/' . $item['id'] . '/remove')) ?>"
                >
                    <?= csrf_field() ?>

                    <button
                        class="secondary-button"
                        type="submit"
                    >
                        Remove bookmark
                    </button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (!$bookmarks): ?>
        <div class="empty-state">
            <h2>No saved stories yet</h2>

            <p>
                Use “Save article” while reading to build your list.
            </p>
        </div>
    <?php endif; ?>

    <div class="section-heading">
        <h2>Recent reading</h2>
    </div>

    <div class="horizontal-grid">
        <?php foreach ($history as $item): ?>
            <?php
            require dirname(__DIR__) . '/partials/article-card.php';
            ?>
        <?php endforeach; ?>
    </div>
</section>