<?php

declare(strict_types=1);

return [
    'name' => env('APP_NAME', 'Saptari Post'),
    'env' => env('APP_ENV', 'production'),
    'debug' => filter_var(env('APP_DEBUG', false), FILTER_VALIDATE_BOOL),
    'url' => rtrim((string) env('APP_URL', 'http://localhost'), '/'),
    'timezone' => env('APP_TIMEZONE', 'Asia/Kathmandu'),
    'locale' => env('APP_LOCALE', 'en'),
    'key' => env('APP_KEY', ''),
    'session_lifetime' => (int) env('SESSION_LIFETIME', 120),
    'upload_max_mb' => (int) env('UPLOAD_MAX_MB', 5),
];
