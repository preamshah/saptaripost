<?php

declare(strict_types=1);

return [
    'session_secure' => filter_var(env('SESSION_SECURE', false), FILTER_VALIDATE_BOOL),
    'login_max_attempts' => 5,
    'login_lock_minutes' => 15,
    'allowed_image_mimes' => ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
    'allowed_image_extensions' => ['jpg', 'jpeg', 'png', 'webp', 'gif'],
];
