-- Saptari Post realistic demo data
-- Import after schema.sql. Demo content and contact details must be replaced before launch.
SET NAMES utf8mb4;

INSERT INTO roles (id, name, slug, description) VALUES
(1,'Super Administrator','super-administrator','Complete system access'),
(2,'Administrator','administrator','Manages users, settings, ads and content'),
(3,'Editor','editor','Reviews, edits, schedules and publishes stories'),
(4,'Reporter / Author','reporter','Manages own reporting'),
(5,'Contributor','contributor','Submits drafts for review'),
(6,'Moderator','moderator','Moderates community content'),
(7,'Registered Reader','registered-reader','Saves and reacts to stories')
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);

INSERT INTO permissions (id, name, slug, group_name) VALUES
(1,'View admin','admin.view','administration'),(2,'Manage users','users.manage','users'),(3,'Create articles','articles.create','articles'),
(4,'Edit all articles','articles.edit_all','articles'),(5,'Publish articles','articles.publish','articles'),(6,'Delete articles','articles.delete','articles'),
(7,'Manage categories','categories.manage','taxonomy'),(8,'Manage media','media.manage','media'),(9,'Moderate comments','comments.moderate','community'),
(10,'Manage advertisements','ads.manage','advertising'),(11,'Manage settings','settings.manage','administration'),(12,'Manage polls','polls.manage','community'),
(13,'View analytics','analytics.view','analytics'),(14,'Manage homepage','homepage.manage','content'),(15,'Manage own articles','articles.manage_own','articles')
ON DUPLICATE KEY UPDATE name=VALUES(name), group_name=VALUES(group_name);

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT 2,id FROM permissions;
INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(3,1),(3,3),(3,4),(3,5),(3,6),(3,7),(3,8),(3,9),(3,12),(3,13),(3,14),
(4,1),(4,3),(4,8),(4,13),(4,15),(5,1),(5,3),(5,8),(5,15),(6,1),(6,9);

-- Password for every demo account below: ChangeMe!2026
-- The bcrypt hash was generated with cost 12. Change every demo password immediately.
INSERT INTO users (id, role_id, name, slug, email, password_hash, bio, status, email_verified_at, must_change_password, created_at, updated_at) VALUES
(1,1,'Saptari Post Administrator','saptari-post-administrator','admin@saptaripost.local','$2b$12$Snh.vw3k5x3PzL1paRkP0eskY.dPBsDn/s412oLgIl3xehdPdCG3y','Demo super administrator. Replace this profile and email before launch.','active',NOW(),1,NOW(),NOW()),
(2,3,'Anisha Karki','anisha-karki','editor@saptaripost.local','$2b$12$Snh.vw3k5x3PzL1paRkP0eskY.dPBsDn/s412oLgIl3xehdPdCG3y','Demo editor focused on public policy and accountability.','active',NOW(),1,NOW(),NOW()),
(3,4,'Ramesh Yadav','ramesh-yadav','reporter@saptaripost.local','$2b$12$Snh.vw3k5x3PzL1paRkP0eskY.dPBsDn/s412oLgIl3xehdPdCG3y','Demo Madhesh Province reporter covering agriculture, local government and livelihoods.','active',NOW(),1,NOW(),NOW()),
(4,7,'Demo Reader','demo-reader','reader@saptaripost.local','$2b$12$Snh.vw3k5x3PzL1paRkP0eskY.dPBsDn/s412oLgIl3xehdPdCG3y','Demo registered reader account.','active',NOW(),1,NOW(),NOW())
ON DUPLICATE KEY UPDATE name=VALUES(name), bio=VALUES(bio);

INSERT INTO authors (user_id, designation, expertise, profile_verified) VALUES
(2,'Editor','Politics, public policy, accountability',1),(3,'Province Reporter','Agriculture, local government, Madhesh Province',1)
ON DUPLICATE KEY UPDATE designation=VALUES(designation), expertise=VALUES(expertise);

INSERT INTO categories (id,parent_id,name,name_ne,slug,description,is_active,display_order) VALUES
(1,NULL,'Nepal News','नेपाल समाचार','nepal-news','Verified national reporting and public-interest developments from across Nepal.',1,1),
(2,NULL,'Politics','राजनीति','politics','Government, parliament, elections, policy and political accountability.',1,2),
(3,NULL,'Business & Economy','व्यापार तथा अर्थतन्त्र','business-economy','Markets, enterprise, public finance, employment and the economy.',1,3),
(4,NULL,'Technology','प्रविधि','technology','Digital policy, startups, cybersecurity and practical technology.',1,4),
(5,NULL,'Sports','खेलकुद','sports','Nepali and international sport with results, profiles and analysis.',1,5),
(6,NULL,'Health','स्वास्थ्य','health','Evidence-based public health, hospitals and wellbeing coverage.',1,6),
(7,NULL,'Tourism','पर्यटन','tourism','Destinations, conservation, aviation and tourism enterprise.',1,7),
(8,NULL,'Agriculture','कृषि','agriculture','Farm policy, markets, climate resilience and rural livelihoods.',1,8),
(9,NULL,'Entertainment','मनोरञ्जन','entertainment','Film, music, arts and culture.',1,9),
(10,NULL,'Education','शिक्षा','education','Schools, universities, skills and education policy.',1,10),
(11,NULL,'Crime & Security','अपराध तथा सुरक्षा','crime-security','Careful, victim-sensitive reporting on justice and public safety.',1,11),
(12,NULL,'Province News','प्रदेश समाचार','province-news','Reporting from all seven provinces of Nepal.',1,12),
(13,NULL,'International','अन्तर्राष्ट्रिय','international','Important global developments explained for Nepali readers.',1,13),
(14,NULL,'Opinion','विचार','opinion','Clearly labelled commentary, analysis and expert perspectives.',1,14),
(15,NULL,'Lifestyle','जीवनशैली','lifestyle','Food, family, travel and everyday life.',1,15),
(16,NULL,'Weather','मौसम','weather','Weather updates, climate impacts and safety information.',1,16),
(17,12,'Koshi Province','कोशी प्रदेश','koshi-province','Koshi Province reporting.',1,1),
(18,12,'Madhesh Province','मधेश प्रदेश','madhesh-province','Madhesh Province reporting.',1,2),
(19,12,'Bagmati Province','बागमती प्रदेश','bagmati-province','Bagmati Province reporting.',1,3),
(20,12,'Gandaki Province','गण्डकी प्रदेश','gandaki-province','Gandaki Province reporting.',1,4),
(21,12,'Lumbini Province','लुम्बिनी प्रदेश','lumbini-province','Lumbini Province reporting.',1,5),
(22,12,'Karnali Province','कर्णाली प्रदेश','karnali-province','Karnali Province reporting.',1,6),
(23,12,'Sudurpashchim Province','सुदूरपश्चिम प्रदेश','sudurpashchim-province','Sudurpashchim Province reporting.',1,7)
ON DUPLICATE KEY UPDATE name=VALUES(name), name_ne=VALUES(name_ne), description=VALUES(description);

INSERT INTO tags (id,name,slug) VALUES (1,'Federal Parliament','federal-parliament'),(2,'Madhesh','madhesh'),(3,'Agriculture','agriculture'),(4,'Digital Nepal','digital-nepal'),(5,'Public Health','public-health'),(6,'Tourism','tourism'),(7,'Climate','climate'),(8,'Economy','economy')
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO articles (id,category_id,author_id,language,title,subtitle,slug,excerpt,body,featured_image,image_alt,image_caption,image_credit,status,seo_title,meta_description,is_featured,featured_order,is_breaking,is_trending,is_editors_pick,is_exclusive,is_live,is_video,allow_comments,views_count,published_at,created_at,updated_at) VALUES
(1,1,2,'en','Local governments expand digital public-service counters across Nepal','Municipal teams say the next challenge is making online services usable for citizens with limited connectivity.','local-governments-expand-digital-public-service-counters','Municipalities are adding assisted digital counters while reviewing accessibility and data-protection safeguards.','<p>Local governments in several provinces are expanding assisted digital counters for registration, recommendations and revenue services.</p><h2>Access remains the central test</h2><p>Officials involved in the pilot say a service should not be called digital merely because a form is online. Citizens need clear instructions, predictable processing times and an offline route when connectivity fails.</p><blockquote>Public technology earns trust when people can understand it, use it and challenge mistakes.</blockquote><p>The demo report illustrates the article workflow and must be replaced with verified newsroom reporting before launch.</p>','assets/images/news-placeholder.svg','Abstract Saptari Post editorial placeholder','Demo illustration for the sample report','Saptari Post demo artwork','published','Nepal municipalities expand digital public services','Municipalities are expanding assisted digital counters while focusing on accessibility, service standards and privacy.',1,1,1,1,1,0,0,0,1,18450,DATE_SUB(NOW(),INTERVAL 2 HOUR),NOW(),NOW()),
(2,2,2,'en','Parliamentary committees publish a clearer calendar for public hearings',NULL,'parliamentary-committees-publish-clearer-calendar','The published schedule gives civil society and subject experts more time to prepare evidence.','<p>Several parliamentary committees have begun publishing hearing dates and agenda notes earlier, a change transparency advocates have long requested.</p><h2>Why notice periods matter</h2><p>Earlier publication does not guarantee meaningful consultation, but it gives experts and affected communities a better opportunity to prepare evidence. Editors should verify all schedules against official parliamentary records before publication.</p>','assets/images/news-placeholder.svg','Sample illustration for parliament story','Demo illustration','Saptari Post demo artwork','published',NULL,'A clearer committee calendar could make public participation in parliamentary hearings more practical.',1,2,0,1,1,0,0,0,1,13380,DATE_SUB(NOW(),INTERVAL 5 HOUR),NOW(),NOW()),
(3,3,2,'en','Small exporters focus on quality standards as regional demand grows',NULL,'small-exporters-focus-on-quality-standards','Entrepreneurs say testing, packaging and predictable logistics matter as much as access to buyers.','<p>Small Nepali producers seeking regional customers are investing more attention in product testing, traceability and consistent packaging.</p><h2>Beyond market access</h2><p>Business groups say trade promotion is useful only when firms can meet standards repeatedly and move goods on predictable schedules. This demonstration article contains no live market recommendation.</p>','assets/images/news-placeholder.svg','Abstract business news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Small exporters are prioritizing testing, packaging and logistics as they explore regional markets.',1,3,0,1,0,0,0,0,1,9820,DATE_SUB(NOW(),INTERVAL 9 HOUR),NOW(),NOW()),
(4,4,2,'en','Nepali startups design services for low-bandwidth users first',NULL,'nepali-startups-design-for-low-bandwidth-users','Product teams are treating slow connections and older phones as core design constraints.','<p>A growing group of product teams is designing essential flows to work on slow mobile connections and lower-cost devices.</p><h2>Performance is an access issue</h2><p>Light pages, short forms and clear recovery messages can determine whether someone completes a payment or abandons it. Security testing and privacy review remain essential even for lightweight services.</p>','assets/images/news-placeholder.svg','Technology story placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Nepali product teams are treating low bandwidth and older devices as primary design constraints.',0,0,0,1,1,0,0,0,1,8740,DATE_SUB(NOW(),INTERVAL 14 HOUR),NOW(),NOW()),
(5,5,3,'en','Community grounds create more playing time for young athletes',NULL,'community-grounds-create-more-playing-time','Local clubs are coordinating shared schedules, coaching and basic safety standards.','<p>Community clubs in several towns are sharing grounds and coaching hours so younger athletes can train more regularly.</p><h2>Simple systems help</h2><p>Published schedules, safe equipment and trained volunteers can make limited facilities more useful. Results and names in any live version of this report must be confirmed with organizers.</p>','assets/images/news-placeholder.svg','Sports news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Community clubs are coordinating grounds and coaching to expand youth participation in sport.',0,0,0,0,0,0,0,0,1,6450,DATE_SUB(NOW(),INTERVAL 20 HOUR),NOW(),NOW()),
(6,6,2,'en','Health desks prioritize clear referral information during monsoon season',NULL,'health-desks-prioritize-clear-referral-information','Public notices focus on when to seek urgent care and where verified services are available.','<p>Local health desks are updating referral information as seasonal illness and transport disruption increase pressure on patients.</p><h2>Information is not medical advice</h2><p>Public guidance should use verified clinical sources and direct people to qualified care. This demonstration content is not individualized medical advice and must not replace official health alerts.</p>','assets/images/news-placeholder.svg','Health coverage placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Local health desks are improving referral information during the monsoon season.',0,0,0,0,0,0,0,0,1,5310,DATE_SUB(NOW(),INTERVAL 1 DAY),NOW(),NOW()),
(7,7,3,'en','Homestay groups map visitor capacity before the autumn season',NULL,'homestay-groups-map-visitor-capacity','Local operators are recording room capacity, walking routes and emergency contacts.','<p>Homestay groups are compiling shared visitor information before the autumn travel season.</p><h2>Reliable information supports trust</h2><p>Operators say accurate capacity, transport and emergency details reduce confusion for guests and distribute bookings more fairly. Travellers should verify conditions directly before making plans.</p>','assets/images/news-placeholder.svg','Tourism news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Homestay groups are mapping capacity, routes and emergency contacts ahead of autumn travel.',0,0,0,0,1,0,0,0,1,4770,DATE_SUB(NOW(),INTERVAL 28 HOUR),NOW(),NOW()),
(8,8,3,'en','Farm cooperatives test shared crop records to improve market planning',NULL,'farm-cooperatives-test-shared-crop-records','The records aim to reduce guesswork without exposing individual farmers’ sensitive information.','<p>Several farm cooperatives are testing shared crop calendars and volume estimates to coordinate transport and market timing.</p><h2>Data needs safeguards</h2><p>Cooperative leaders say members must understand who can see the records and how estimates will be used. Aggregated information can support planning while limiting exposure of individual farm data.</p>','assets/images/news-placeholder.svg','Agriculture news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Farm cooperatives are testing shared crop records for transport and market planning.',0,0,0,1,1,1,0,0,1,7650,DATE_SUB(NOW(),INTERVAL 32 HOUR),NOW(),NOW()),
(9,9,2,'en','Independent film workshops bring production training outside Kathmandu',NULL,'independent-film-workshops-expand-production-training','Short workshops focus on story development, sound recording and responsible documentary practice.','<p>Independent film groups are organizing short production workshops in provincial cities.</p><h2>Practical training close to home</h2><p>Participants are learning story structure, location sound, interview consent and low-cost editing. Organizers say local mentorship after a workshop matters more than a one-time event.</p>','assets/images/news-placeholder.svg','Entertainment news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Independent film workshops are expanding practical production training in provincial cities.',0,0,0,0,0,0,0,1,1,3920,DATE_SUB(NOW(),INTERVAL 2 DAY),NOW(),NOW()),
(10,13,2,'en','Regional cities compare heat-action plans as summers grow more intense',NULL,'regional-cities-compare-heat-action-plans','Officials are examining early warnings, worker protection and access to drinking water.','<p>Cities across South Asia are comparing heat-action measures as longer hot periods affect health, schools and outdoor work.</p><h2>Local plans need local thresholds</h2><p>Experts caution that warnings must reflect local humidity, housing and work patterns. This sample international report should be replaced with sourced, current reporting.</p>','assets/images/news-placeholder.svg','International climate news placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'South Asian cities are comparing heat-action plans focused on warnings, workers and drinking water.',0,0,0,1,0,0,0,0,1,11220,DATE_SUB(NOW(),INTERVAL 3 DAY),NOW(),NOW()),
(11,14,2,'en','Opinion: Local data should make public decisions easier to question',NULL,'opinion-local-data-public-decisions','Publishing data is only the first step; context, definitions and correction channels matter too.','<p><strong>Opinion:</strong> Public institutions increasingly publish dashboards, but disclosure alone does not create accountability.</p><h2>Explain what the numbers mean</h2><p>Datasets need definitions, update schedules and a visible route for reporting errors. Citizens should be able to understand how a number was produced and which decision it informed.</p>','assets/images/news-placeholder.svg','Opinion article placeholder','Demo illustration','Saptari Post demo artwork','published',NULL,'Opinion on making public data understandable, contestable and useful in local decision-making.',0,0,0,0,1,0,0,0,1,6890,DATE_SUB(NOW(),INTERVAL 4 DAY),NOW(),NOW()),
(12,18,3,'ne','मधेशका किसान समूहले साझा बजार सूचना प्रणाली परीक्षण गर्दै','मूल्य, ढुवानी र मागसम्बन्धी जानकारी समयमै उपलब्ध गराउने लक्ष्य राखिएको छ।','madhesh-farmer-groups-test-shared-market-information','किसान समूहले व्यक्तिगत विवरण सुरक्षित राख्दै बजारसम्बन्धी उपयोगी सूचना साझा गर्ने अभ्यास थालेका छन्।','<p>मधेश प्रदेशका केही किसान समूहले उत्पादन, ढुवानी र बजार मागसम्बन्धी सूचना साझा गर्ने अभ्यास थालेका छन्।</p><h2>सूचनासँगै गोपनीयता पनि आवश्यक</h2><p>सहकारीका प्रतिनिधिहरूका अनुसार कुन विवरण कसले हेर्न पाउने भन्ने स्पष्ट नियम आवश्यक छ। यो नमुना सामग्री हो; सार्वजनिक गर्नुअघि वास्तविक तथ्य, स्थान र स्रोतबाट पुष्टि गर्नुपर्छ।</p>','assets/images/news-placeholder.svg','मधेश कृषि समाचारको नमुना चित्र','नमुना चित्र','Saptari Post demo artwork','published',NULL,'मधेशका किसान समूहले बजार र ढुवानी योजना सुधार्न साझा सूचना प्रणाली परीक्षण गरेका छन्।',1,4,0,1,0,0,0,0,1,8210,DATE_SUB(NOW(),INTERVAL 7 HOUR),NOW(),NOW())
ON DUPLICATE KEY UPDATE title=VALUES(title), body=VALUES(body), updated_at=NOW();

INSERT IGNORE INTO article_tags (article_id,tag_id) VALUES (1,4),(2,1),(3,8),(4,4),(6,5),(7,6),(8,2),(8,3),(10,7),(12,2),(12,3);

INSERT INTO comments (article_id,user_id,guest_name,guest_email,body,status,ip_hash,created_at,updated_at) VALUES
(1,4,'Demo Reader','reader@saptaripost.local','The focus on assisted access is useful. Publishing service standards would make the next report even stronger.','approved',REPEAT('0',64),NOW(),NOW()),
(8,NULL,'Sample Farmer','sample@example.com','Please include verified collection-centre contacts when this becomes a real report.','pending',REPEAT('1',64),NOW(),NOW());

INSERT INTO advertisements (id,name,placement,ad_type,image_path,destination_url,device_target,is_active,display_order,start_at,end_at) VALUES
(1,'Demo Header Reservation','header_banner','image',NULL,NULL,'all',0,1,NULL,NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO menus (id,name,location,is_active) VALUES (1,'Primary Navigation','primary',1),(2,'Footer Policies','footer_policies',1)
ON DUPLICATE KEY UPDATE name=VALUES(name);
INSERT IGNORE INTO menu_items (menu_id,label,label_ne,url,display_order) VALUES
(1,'Home','गृहपृष्ठ','/',1),(1,'Latest','ताजा समाचार','/latest',2),(1,'Politics','राजनीति','/category/politics',3),(1,'Business','व्यापार','/category/business-economy',4),(1,'Technology','प्रविधि','/category/technology',5);

INSERT INTO homepage_sections (section_key,title,title_ne,category_id,layout,item_limit,display_order,is_active) VALUES
('featured','Top Stories','मुख्य समाचार',NULL,'hero',5,1,1),('latest','Latest News','ताजा समाचार',NULL,'grid',10,2,1),
('province','Province News','प्रदेश समाचार',12,'grid',4,3,1),('business','Business & Economy','व्यापार तथा अर्थतन्त्र',3,'grid',4,4,1),
('technology','Technology','प्रविधि',4,'grid',4,5,1),('sports','Sports','खेलकुद',5,'grid',4,6,1),
('entertainment','Entertainment','मनोरञ्जन',9,'grid',4,7,1),('international','International','अन्तर्राष्ट्रिय',13,'grid',4,8,1)
ON DUPLICATE KEY UPDATE title=VALUES(title), category_id=VALUES(category_id), is_active=VALUES(is_active);

INSERT INTO polls (id,question,question_ne,status,starts_at,ends_at,created_by) VALUES
(1,'Which public service should local governments prioritize online?','स्थानीय सरकारले कुन सार्वजनिक सेवा अनलाइनमा प्राथमिकता दिनुपर्छ?','active',NOW(),DATE_ADD(NOW(),INTERVAL 30 DAY),2)
ON DUPLICATE KEY UPDATE question=VALUES(question);
INSERT IGNORE INTO poll_options (id,poll_id,option_text,option_text_ne,display_order) VALUES
(1,1,'Civil registration','व्यक्तिगत घटना दर्ता',1),(2,1,'Local tax payment','स्थानीय कर भुक्तानी',2),(3,1,'Public grievance tracking','सार्वजनिक गुनासो अनुगमन',3);

INSERT INTO galleries (id,title,slug,description,cover_image,is_published,published_at,created_by) VALUES
(1,'A visual guide to the Saptari Post demo newsroom','saptari-post-demo-newsroom','Original placeholder artwork demonstrates gallery layout without using copyrighted news photographs.','assets/images/news-placeholder.svg',1,DATE_SUB(NOW(),INTERVAL 1 DAY),2)
ON DUPLICATE KEY UPDATE title=VALUES(title),description=VALUES(description);
INSERT IGNORE INTO gallery_items (gallery_id,image_path,caption,credit,display_order) VALUES
(1,'assets/images/news-placeholder.svg','Demo editorial illustration','Saptari Post demo artwork',1),(1,'assets/images/social-card.svg','Demo social card','Saptari Post demo artwork',2);

INSERT INTO settings (group_name,setting_key,setting_value,field_type,is_public) VALUES
('general','site.name','Saptari Post','text',1),('general','site.tagline','Nepal News, Insight and Context','text',1),
('general','contact.email','info@saptaripost.com','email',1),('general','contact.phone','CUSTOMIZE BEFORE LAUNCH','text',1),
('general','contact.address','CUSTOMIZE BEFORE LAUNCH','textarea',1),('general','maintenance.enabled','0','text',0),
('seo','seo.default_title','Saptari Post — Nepal News, Insight and Context','text',1),('seo','seo.default_description','Independent Nepal news covering politics, business, technology, provinces, sports and international developments.','textarea',1),
('seo','seo.google_verification','','text',0),('seo','seo.bing_verification','','text',0),
('analytics','analytics.ga4_id','','text',0),('analytics','analytics.gtm_id','','text',0),
('social','social.facebook','','text',1),('social','social.x','','text',1),('social','social.youtube','','text',1),
('email','mail.from_name','Saptari Post','text',0),('email','mail.from_address','info@saptaripost.com','email',0),
('advertising','ads.enabled','0','text',0),('advertising','ads.publisher_id','','text',0)
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),field_type=VALUES(field_type);

INSERT INTO newsletter_subscribers (email,name,status,verified_at) VALUES ('demo-subscriber@example.com','Demo Subscriber','active',NOW())
ON DUPLICATE KEY UPDATE name=VALUES(name);
