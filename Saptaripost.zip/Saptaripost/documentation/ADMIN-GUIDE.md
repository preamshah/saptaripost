# Saptari Post Admin Guide

## Editorial workflow

1. A contributor creates a draft and submits it as **Pending review**.
2. A reporter manages only their own stories unless granted broader permissions.
3. An editor checks sourcing, fairness, headline accuracy, media rights, alt text and SEO fields.
4. An editor publishes immediately or selects **Scheduled** with a future time.
5. Every edit stores the prior headline, body and status in `article_revisions`.
6. Deletion is soft; the article receives `deleted_at` instead of immediate physical removal.

Story flags control lead placement, breaking news, trending, editor selections, exclusives, live updates and video archives. Use them selectively.

## Article editor

The editor accepts a constrained HTML set: paragraphs, H2–H4 headings, lists, safe links/images, captions, blockquotes, tables and YouTube embed URLs. Event handlers, inline style and unsafe URL schemes are removed on the server. Browser-local autosave protects unfinished body text but is not a server revision until **Save article** is pressed.

For media, upload in **Media Library**, copy the returned path and add it to the article. Every meaningful image needs accurate alt text, caption and credit/source. Never upload executable files or images without usage rights.

## Roles

| Role | Intended access |
| --- | --- |
| Super Administrator | Full access; reserve for one or two trusted owners |
| Administrator | Users, configuration, advertising and newsroom management |
| Editor | Review, edit, schedule, publish, moderate and organize stories |
| Reporter | Create and manage own stories; publishing depends on permission |
| Contributor | Draft and submit for review only |
| Moderator | Review comments and community messages |
| Registered Reader | Public dashboard, bookmarks and reactions |

Permissions are normalized in `permissions` and `role_permissions`. Extend the role UI by following the prepared-statement and CSRF patterns in `AdminController`.

## Media and comments

Media is validated by upload error, size, MIME type, decoded-image metadata and a randomized server filename. Comments begin in **Pending** and may be approved, rejected or marked spam. Do not publish private contact information or unverified allegations from comments.

## Advertising

Every placement is visibly labelled. Keep direct ads separate from navigation, reserve layout space and set campaign dates. Third-party ad code is intentionally powerful; only a trusted administrator should add it. Clicks on image/direct ads pass through the tracked redirect endpoint.

## Secondary modules

Users, tags, messages, newsletter subscribers, polls, galleries, homepage sections, menus, redirects and logs have normalized storage and safe listing views. The core release prioritizes full editorial CRUD. When adding edit actions, use an explicit table/field allowlist, CSRF validation, role permission checks, server validation, prepared statements and activity logs.

## Daily checklist

- Review scheduled and pending stories.
- Moderate comments and correction requests.
- Check the activity log and unusual login failures.
- Verify lead, breaking and trending selections.
- Confirm campaign end dates.
- Check backup completion and error logs.
