# Advertising and AdSense Setup

The portal is designed for responsible advertising placement; it does not guarantee AdSense or Google Ads approval.

## Direct campaigns

Use **Admin → Advertisements** to set the campaign name, placement, type, destination, date range, device target, status and order. Image ads use the tracked `/ad/click/{id}` redirect. All slots are labelled and reserve height to reduce cumulative layout shift.

## AdSense preparation

1. Publish substantial original content and complete the policy, ownership, author and contact pages.
2. Verify the site follows current [Google Publisher Policies](https://support.google.com/publisherpolicies/answer/10502938).
3. Apply using the final production domain and publisher identity.
4. Only after authorization, add the exact seller record supplied by Google to `public/ads.txt` and replace the commented example.
5. Add the approved script to controlled layout or placement code, update CSP for the exact required domains, and test consent behavior.
6. Keep ads away from navigation, voting, download and sharing controls. Do not encourage clicks.
7. Monitor page speed, layout stability, invalid traffic and policy notifications.

## Consent and privacy

The bundled banner acknowledges essential cookies only; it is not a full consent-management platform. Before enabling personalized advertising or analytics, configure a consent solution appropriate to the publisher’s users and legal obligations. Document vendors, purposes, retention and opt-out controls in the privacy and cookie policies.

## Placement principles

- Never allow ads to outnumber meaningful editorial content.
- Keep the advertisement label visible.
- Reserve dimensions before third-party code loads.
- Use lazy loading where the vendor permits it.
- Review mobile anchor behavior so it does not obscure content or controls.
- Restrict raw ad-code access to trusted administrators.
