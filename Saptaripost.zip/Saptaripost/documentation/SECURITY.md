# Security Guide

This project uses prepared PDO statements, password hashing, CSRF tokens, session regeneration, SameSite/HttpOnly cookies, login throttling, role checks, server-side output escaping, restricted HTML sanitization, security headers and strict image validation. Security is an ongoing operational process, not a one-time configuration.

## Required launch actions

1. Replace every demo credential and remove unused demo accounts.
2. Generate a unique `APP_KEY`, keep `.env` outside version control and set `APP_DEBUG=false`.
3. Enforce HTTPS and `SESSION_SECURE=true`.
4. Use a database account limited to the Saptari Post database; do not use MySQL root.
5. Point the document root to `/public` and verify `.env`, SQL, logs, uploads and backups cannot execute or download unexpectedly.
6. Keep PHP, the web server and database on supported security releases.
7. Restrict admin access, require unique password-manager-generated credentials and add MFA through the organization’s identity layer if available.
8. Back up the database and uploads, encrypt off-site copies and test restoration.

## Uploads

The uploader checks the PHP error, maximum bytes, Fileinfo MIME, image decoding and an allowlist; filenames use cryptographic randomness. Apache rules deny common executable extensions. For stronger isolation, serve uploads from a separate static hostname with no script execution and scan media with the host’s malware service.

## Sessions and authentication

Login failures are counted by email and a salted one-way IP hash for 15 minutes. Successful login regenerates the session ID. Password-reset tokens are random, stored only as SHA-256 hashes, expire after one hour and are single-use. Schedule cleanup with `scripts/publish-scheduled.php`.

## Content Security Policy

The default CSP permits local assets, Bootstrap from jsDelivr and YouTube embeds. Adding analytics, advertising or another embed requires a deliberate CSP update. Avoid a broad wildcard. Third-party ad code is administrator-trusted HTML/JavaScript and must never be editable by lower roles.

## Logs and incident response

PHP errors write to `storage/logs/php-error.log`. Activity logs record privileged changes using hashed IP values. Protect logs from web access and define retention. If compromise is suspected: take the site into maintenance, preserve logs, rotate application/database/mail credentials, revoke sessions, identify the entry point, restore from a known-good backup, patch, and notify affected people as required.

Use the [OWASP Application Security Verification Standard](https://owasp.org/www-project-application-security-verification-standard/) and [OWASP File Upload Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html) for a pre-launch review.
