# SEO and Google News Readiness

## Included

- Unique title/description variables, canonical links, robots controls, Open Graph and X card metadata
- NewsMediaOrganization and NewsArticle JSON-LD
- Permanent article URLs under `/news/{category}/{slug}`
- Category, province and author archives with internal linking
- `sitemap.xml`, `news-sitemap.xml`, `page-sitemap.xml`, `rss.xml` and dynamic `robots.txt`
- Visible authors, biographies, publication/update times, captions and credits
- About, editorial, correction, ownership/funding, privacy, terms, disclaimer, cookie, copyright, community, contact and advertising pages
- `noindex` on login, registration, recovery, reader, admin and internal search pages

## Before submission

1. Replace all demo stories and placeholders with original, verified reporting.
2. Publish complete publisher, ownership, funding, contact and author information.
3. Confirm every sitemap URL returns 200 with the production HTTPS canonical.
4. Validate JSON-LD with Google’s Rich Results Test and inspect rendered source.
5. Add Search Console/Bing verification, submit the sitemap index and monitor crawl errors.
6. Keep article URLs stable; use the redirects table and a 301 handler when slugs change.
7. Use licensed, sufficiently large lead images with visible credits and descriptive alt text.
8. Set an editorial schedule that supports consistent original reporting.

The news sitemap includes only articles published in the previous two days, following [Google’s news sitemap guidance](https://developers.google.com/search/docs/crawling-indexing/sitemaps/news-sitemap). Structured data follows Google’s [Article documentation](https://developers.google.com/search/docs/appearance/structured-data/article). These measures improve technical readiness but do not guarantee indexing, rankings or Google News inclusion.

## Performance

Set explicit image dimensions, use appropriately sized WebP/AVIF derivatives, lazy-load non-lead images, keep the lead image high priority, reserve ad height and cache static assets. Test representative pages with Lighthouse and real-user Core Web Vitals. Download Bootstrap locally when eliminating the CDN is operationally preferable.
