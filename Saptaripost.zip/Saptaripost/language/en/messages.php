<?php

return [
    'home' => 'Home',
    'latest_news' => 'Latest News',
    'trending' => 'Trending',
    'most_read' => 'Most Read',
    'search' => 'Search',
    'sign_in' => 'Sign in',
    'read_more' => 'Read more',
    'published' => 'Published',
    'updated' => 'Updated',
    'comments' => 'Comments',
    'newsletter' => 'Newsletter',
];
