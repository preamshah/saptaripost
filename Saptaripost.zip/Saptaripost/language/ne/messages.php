<?php

return [
    'home' => 'गृहपृष्ठ',
    'latest_news' => 'ताजा समाचार',
    'trending' => 'चर्चित',
    'most_read' => 'धेरै पढिएका',
    'search' => 'खोज्नुहोस्',
    'sign_in' => 'साइन इन',
    'read_more' => 'थप पढ्नुहोस्',
    'published' => 'प्रकाशित',
    'updated' => 'अद्यावधिक',
    'comments' => 'टिप्पणीहरू',
    'newsletter' => 'न्युजलेटर',
];
