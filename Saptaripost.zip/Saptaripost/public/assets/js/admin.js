(() => {
  'use strict';
  const sidebar = document.querySelector('#adminSidebar');
  document.querySelector('#adminMenu')?.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelectorAll('[data-confirm]').forEach(form => form.addEventListener('submit', event => { if (!confirm(form.dataset.confirm)) event.preventDefault(); }));
  document.querySelectorAll('[data-copy]').forEach(button => button.addEventListener('click', async () => { await navigator.clipboard.writeText(button.dataset.copy); button.textContent = 'Copied'; }));

  const title = document.querySelector('[data-slug-source]');
  const slug = document.querySelector('[data-slug-target]');
  title?.addEventListener('input', () => {
    if (slug.dataset.edited) return;
    slug.value = title.value.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  });
  slug?.addEventListener('input', () => { slug.dataset.edited = 'true'; });

  const editor = document.querySelector('[data-autosave]');
  const form = document.querySelector('#articleEditor');
  const status = document.querySelector('#autosaveStatus');
  const key = form ? `saptari-draft:${location.pathname}` : '';
  if (editor && form) {
    const saved = localStorage.getItem(key);
    if (saved && !editor.value && confirm('Restore the local autosaved draft?')) editor.value = saved;
    let timer;
    editor.addEventListener('input', () => { clearTimeout(timer); status.textContent = 'Unsaved local changes…'; timer = setTimeout(() => { localStorage.setItem(key, editor.value); status.textContent = `Local draft saved at ${new Date().toLocaleTimeString()}`; }, 900); });
    form.addEventListener('submit', () => localStorage.removeItem(key));
  }
  document.querySelectorAll('[data-wrap-tag]').forEach(button => button.addEventListener('click', () => {
    if (!editor) return;
    const tag = button.dataset.wrapTag;
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const selected = editor.value.slice(start, end) || (tag === 'a' ? 'link text' : 'Text');
    let html = `<${tag}>${selected}</${tag}>`;
    if (tag === 'a') html = `<a href="https://">${selected}</a>`;
    if (tag === 'ul') html = `<ul><li>${selected}</li></ul>`;
    editor.setRangeText(html, start, end, 'end');
    editor.dispatchEvent(new Event('input', {bubbles:true}));
    editor.focus();
  }));
})();
