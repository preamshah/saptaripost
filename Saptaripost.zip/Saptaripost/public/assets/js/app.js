(() => {
  'use strict';
  const html = document.documentElement;
  const themeButton = document.querySelector('#themeToggle');
  const savedTheme = localStorage.getItem('saptari-theme');
  const preferredDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  html.dataset.theme = savedTheme || (preferredDark ? 'dark' : 'light');
  themeButton?.addEventListener('click', () => {
    html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('saptari-theme', html.dataset.theme);
  });

  const menuButton = document.querySelector('#menuToggle');
  const menu = document.querySelector('#primaryMenu');
  menuButton?.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });

  const searchButton = document.querySelector('#searchToggle');
  const searchPanel = document.querySelector('#searchPanel');
  searchButton?.addEventListener('click', () => {
    searchPanel.hidden = !searchPanel.hidden;
    if (!searchPanel.hidden) searchPanel.querySelector('input')?.focus();
  });

  const searchInput = document.querySelector('[data-suggestions]');
  const suggestions = document.querySelector('#searchSuggestions');
  let searchTimer;
  searchInput?.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const query = searchInput.value.trim();
    if (query.length < 2) { suggestions.innerHTML = ''; return; }
    searchTimer = setTimeout(async () => {
      try {
        const response = await fetch(`${searchInput.dataset.suggestions}?q=${encodeURIComponent(query)}`, {headers: {'Accept':'application/json'}});
        if (!response.ok) return;
        const items = await response.json();
        suggestions.innerHTML = items.map(item => `<a href="${window.APP_BASE || ''}/news/${encodeURIComponent(item.category_slug)}/${encodeURIComponent(item.slug)}">${escapeHtml(item.title)}</a>`).join('');
      } catch (_) { suggestions.innerHTML = ''; }
    }, 220);
  });

  const escapeHtml = value => String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const progress = document.querySelector('#readingProgress');
  const backToTop = document.querySelector('#backToTop');
  const onScroll = () => {
    const total = document.documentElement.scrollHeight - innerHeight;
    if (progress) progress.style.width = `${total > 0 ? (scrollY / total) * 100 : 0}%`;
    backToTop?.classList.toggle('visible', scrollY > 600);
  };
  addEventListener('scroll', onScroll, {passive:true});
  onScroll();
  backToTop?.addEventListener('click', () => scrollTo({top:0, behavior:'smooth'}));

  document.querySelectorAll('[data-copy-link]').forEach(button => button.addEventListener('click', async () => {
    await navigator.clipboard.writeText(location.href);
    const previous = button.textContent; button.textContent = 'Copied'; setTimeout(() => button.textContent = previous, 1300);
  }));
  document.querySelectorAll('[data-native-share]').forEach(button => button.addEventListener('click', () => {
    if (navigator.share) navigator.share({title:document.title, url:location.href}).catch(() => {});
    else navigator.clipboard.writeText(location.href);
  }));
  const articleBody = document.getElementById('articleBody');
const fontButtons = document.querySelectorAll('[data-font]');

if (articleBody && fontButtons.length) {
  const minimumSize = 14;
  const maximumSize = 30;
  const changeAmount = 2;

  const savedSize = Number(localStorage.getItem('article-font-size'));
  let currentSize = savedSize ||
    parseFloat(window.getComputedStyle(articleBody).fontSize);

  const applyFontSize = () => {
    articleBody.style.setProperty(
      'font-size',
      `${currentSize}px`,
      'important'
    );

    localStorage.setItem(
      'article-font-size',
      String(currentSize)
    );
  };

  if (savedSize) {
    applyFontSize();
  }

  fontButtons.forEach((button) => {
    button.addEventListener('click', () => {
      if (button.dataset.font === 'increase') {
        currentSize = Math.min(
          maximumSize,
          currentSize + changeAmount
        );
      } else {
        currentSize = Math.max(
          minimumSize,
          currentSize - changeAmount
        );
      }

      applyFontSize();
    });
  });
}

  const cookieBanner = document.querySelector('#cookieBanner');
  if (cookieBanner && !localStorage.getItem('essential-cookie-notice')) cookieBanner.hidden = false;
  document.querySelector('[data-cookie-accept]')?.addEventListener('click', () => { localStorage.setItem('essential-cookie-notice','accepted'); cookieBanner.hidden = true; });
})();
