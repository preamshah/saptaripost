<?php

declare(strict_types=1);

use App\Core\Env;
use App\Core\Router;
use App\Core\View;

define('BASE_PATH', dirname(__DIR__));

require BASE_PATH . '/app/Helpers/functions.php';

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = BASE_PATH . '/app/' . $relative . '.php';
    if (is_file($file)) {
        require $file;
    }
});

Env::load(BASE_PATH . '/.env');
date_default_timezone_set((string) config('app.timezone', 'Asia/Kathmandu'));

ini_set('display_errors', config('app.debug') ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');

session_name('saptari_post_session');
session_set_cookie_params([
    'lifetime' => (int) config('app.session_lifetime', 120) * 60,
    'path' => '/',
    'secure' => (bool) config('security.session_secure', false),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' data: https:; frame-src https://www.youtube.com https://www.youtube-nocookie.com; connect-src 'self'");

if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'], true)) {
    $_SESSION['locale'] = $_GET['lang'];
}

$router = new Router();
require BASE_PATH . '/routes/web.php';

try {
    $router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
} catch (Throwable $e) {
    error_log($e->__toString());
    http_response_code(500);
    View::render('errors/500', [
        'title' => 'Something went wrong',
        'message' => config('app.debug') ? $e->getMessage() : 'The request could not be completed. Please try again later.',
    ]);
}

unset($_SESSION['_old']);
