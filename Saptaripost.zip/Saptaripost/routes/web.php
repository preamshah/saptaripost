<?php

declare(strict_types=1);

use App\Controllers\AdminController;
use App\Controllers\AdController;
use App\Controllers\ApiController;
use App\Controllers\ArchiveController;
use App\Controllers\ArticleController;
use App\Controllers\AuthController;
use App\Controllers\FeedController;
use App\Controllers\FormController;
use App\Controllers\HomeController;
use App\Controllers\ReaderController;
use App\Controllers\StaticController;
use App\Middleware\AdminMiddleware;
use App\Middleware\AuthMiddleware;

$router->get('/', [HomeController::class, 'index']);
$router->get('/latest', fn() => (new ArchiveController())->listing('latest'));
$router->get('/trending', fn() => (new ArchiveController())->listing('trending'));
$router->get('/most-read', fn() => (new ArchiveController())->listing('most-read'));
$router->get('/category/{slug}', [ArchiveController::class, 'category']);
$router->get('/province/{slug}', [ArchiveController::class, 'category']);
$router->get('/opinion', fn() => (new ArchiveController())->category('opinion'));
$router->get('/search', [ArchiveController::class, 'search']);
$router->get('/tag/{slug}', [ArchiveController::class, 'tag']);
$router->get('/date/{date}', [ArchiveController::class, 'date']);
$router->get('/authors', [ArchiveController::class, 'authors']);
$router->get('/author/{slug}', [ArchiveController::class, 'author']);
$router->get('/video-news', [ArchiveController::class, 'videos']);
$router->get('/photo-gallery', [ArchiveController::class, 'gallery']);
$router->get('/news/{category}/{slug}', [ArticleController::class, 'show']);
$router->post('/article/{id}/comment', [ArticleController::class, 'comment']);
$router->post('/article/{id}/react', [ArticleController::class, 'react']);
$router->post('/article/{id}/bookmark', [ArticleController::class, 'bookmark'], [AuthMiddleware::class]);

$router->get('/login', [AuthController::class, 'loginForm']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'registerForm']);
$router->post('/register', [AuthController::class, 'register']);
$router->get('/forgot-password', [AuthController::class, 'forgotForm']);
$router->post('/forgot-password', [AuthController::class, 'forgot']);
$router->get('/reset-password/{token}', [AuthController::class, 'resetForm']);
$router->post('/reset-password/{token}', [AuthController::class, 'reset']);
$router->post('/logout', [AuthController::class, 'logout'], [AuthMiddleware::class]);
$router->get('/reader', [ReaderController::class, 'dashboard'], [AuthMiddleware::class]);
$router->post('/reader/bookmark/{id}/remove', [ReaderController::class, 'removeBookmark'], [AuthMiddleware::class]);

$router->post('/contact', [FormController::class, 'contact']);
$router->post('/advertise-with-us', [FormController::class, 'advertise']);
$router->post('/submit-news-tip', [FormController::class, 'tip']);
$router->post('/correction-request', [FormController::class, 'correction']);
$router->post('/newsletter', [FormController::class, 'newsletter']);
$router->post('/poll/{id}/vote', [FormController::class, 'poll']);

foreach (['about-us','contact','advertise-with-us','submit-news-tip','correction-request','privacy-policy','terms-and-conditions','disclaimer','cookie-policy','editorial-policy','corrections-policy','copyright-policy','community-guidelines','ownership-funding-disclosure'] as $page) {
    $router->get('/' . $page, fn() => (new StaticController())->show($page));
}
$router->get('/maintenance', [StaticController::class, 'maintenance']);
$router->get('/rss.xml', [FeedController::class, 'rss']);
$router->get('/sitemap.xml', [FeedController::class, 'sitemap']);
$router->get('/news-sitemap.xml', [FeedController::class, 'newsSitemap']);
$router->get('/page-sitemap.xml', [FeedController::class, 'pageSitemap']);
$router->get('/robots.txt', [FeedController::class, 'robots']);
$router->get('/api/search-suggestions', [ApiController::class, 'suggestions']);
$router->get('/ad/click/{id}', [AdController::class, 'click']);

$admin = [AdminMiddleware::class];
$router->get('/admin', [AdminController::class, 'dashboard'], $admin);
$router->get('/admin/articles', [AdminController::class, 'articles'], $admin);
$router->get('/admin/articles/new', fn() => (new AdminController())->articleForm('new'), $admin);
$router->get('/admin/articles/{id}/edit', [AdminController::class, 'articleForm'], $admin);
$router->post('/admin/articles/new', fn() => (new AdminController())->saveArticle('new'), $admin);
$router->post('/admin/articles/{id}', [AdminController::class, 'saveArticle'], $admin);
$router->post('/admin/articles/{id}/delete', [AdminController::class, 'deleteArticle'], $admin);
$router->get('/admin/categories', [AdminController::class, 'categories'], $admin);
$router->post('/admin/categories', [AdminController::class, 'saveCategory'], $admin);
$router->get('/admin/comments', [AdminController::class, 'comments'], $admin);
$router->post('/admin/comments/{id}', [AdminController::class, 'moderateComment'], $admin);
$router->get('/admin/media', [AdminController::class, 'media'], $admin);
$router->post('/admin/media', [AdminController::class, 'uploadMedia'], $admin);
$router->get('/admin/ads', [AdminController::class, 'ads'], $admin);
$router->post('/admin/ads', [AdminController::class, 'saveAd'], $admin);
$router->get('/admin/settings', [AdminController::class, 'settings'], $admin);
$router->post('/admin/settings', [AdminController::class, 'saveSettings'], $admin);
$router->get('/admin/module/{module}', [AdminController::class, 'module'], $admin);


$router->get(
    '/admin/change-password',
    [AdminController::class, 'changePasswordForm'],
    $admin
);

$router->post(
    '/admin/change-password',
    [AdminController::class, 'changePassword'],
    $admin
);