<?php

declare(strict_types=1);

use App\Core\Database;
use App\Core\Env;

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

define('BASE_PATH', dirname(__DIR__));
require BASE_PATH . '/app/Helpers/functions.php';
spl_autoload_register(static function (string $class): void {
    if (!str_starts_with($class, 'App\\')) return;
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
    if (is_file($file)) require $file;
});
Env::load(BASE_PATH . '/.env');

[$script, $name, $email, $password] = array_pad($argv, 4, null);
if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen((string) $password) < 16) {
    fwrite(STDERR, "Usage: php scripts/create-admin.php \"Full Name\" email@example.com \"password-at-least-16-characters\"\n");
    exit(1);
}

$pdo = Database::connection();
$roleId = $pdo->query("SELECT id FROM roles WHERE slug = 'super-administrator' LIMIT 1")->fetchColumn();
if (!$roleId) {
    fwrite(STDERR, "Import database/schema.sql and database/demo-data.sql first.\n");
    exit(1);
}
$slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)), '-') . '-' . bin2hex(random_bytes(2));
$stmt = $pdo->prepare('INSERT INTO users (role_id, name, slug, email, password_hash, status, email_verified_at, must_change_password, created_at, updated_at) VALUES (?, ?, ?, ?, ?, "active", NOW(), 0, NOW(), NOW())');
$stmt->execute([$roleId, $name, $slug, mb_strtolower($email), password_hash($password, PASSWORD_DEFAULT)]);
fwrite(STDOUT, "Super administrator created: {$email}\n");
