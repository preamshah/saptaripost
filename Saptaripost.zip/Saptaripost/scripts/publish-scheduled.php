<?php

declare(strict_types=1);

use App\Core\Database;
use App\Core\Env;

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

define('BASE_PATH', dirname(__DIR__));
require BASE_PATH . '/app/Helpers/functions.php';
spl_autoload_register(static function (string $class): void {
    if (!str_starts_with($class, 'App\\')) return;
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
    if (is_file($file)) require $file;
});
Env::load(BASE_PATH . '/.env');
date_default_timezone_set((string) config('app.timezone', 'Asia/Kathmandu'));

$pdo = Database::connection();
$published = $pdo->exec("UPDATE articles SET status = 'published', updated_at = NOW() WHERE status = 'scheduled' AND published_at <= NOW() AND deleted_at IS NULL");
$pdo->exec('DELETE FROM password_resets WHERE expires_at < NOW() OR used_at < DATE_SUB(NOW(), INTERVAL 7 DAY)');
$pdo->exec('DELETE FROM email_verification_tokens WHERE expires_at < NOW() OR used_at < DATE_SUB(NOW(), INTERVAL 7 DAY)');
$pdo->exec('DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 30 DAY)');
fwrite(STDOUT, sprintf("%s Published %d scheduled article(s).\n", date(DATE_ATOM), $published));
