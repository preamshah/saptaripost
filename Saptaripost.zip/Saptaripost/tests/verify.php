<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    '.env.example','.htaccess','README.md','INSTALLATION.md','LICENSE','composer.json',
    'database/schema.sql','database/demo-data.sql','public/index.php','public/.htaccess','public/robots.txt','public/ads.txt',
    'public/assets/css/app.css','public/assets/js/app.js','public/assets/js/admin.js',
    'public/assets/images/Saptaripost-logo.svg','public/assets/icons/favicon-Saptripost.svg',
    'routes/web.php','documentation/ADMIN-GUIDE.md','documentation/SECURITY.md','documentation/SEO-GUIDE.md','documentation/ADSENSE-SETUP.md',
];
$failures = [];
foreach ($required as $file) {
    if (!is_file($root . '/' . $file) || filesize($root . '/' . $file) === 0) $failures[] = "Missing or empty: {$file}";
}

$phpFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
$phpCount = 0;
foreach ($phpFiles as $file) {
    if ($file->getExtension() !== 'php') continue;
    $phpCount++;
    $content = file_get_contents($file->getPathname());
    if (!str_contains($content, '<?php')) $failures[] = 'Invalid PHP marker: ' . $file->getPathname();
}

$schema = file_get_contents($root . '/database/schema.sql');
foreach (['users','roles','permissions','articles','categories','tags','media','comments','advertisements','polls','newsletter_subscribers','activity_logs','password_resets'] as $table) {
    if (!preg_match('/CREATE TABLE IF NOT EXISTS ' . preg_quote($table, '/') . '\s*\(/i', $schema)) $failures[] = "Schema table missing: {$table}";
}

if ($failures) {
    fwrite(STDERR, implode("\n", $failures) . "\n");
    exit(1);
}
fwrite(STDOUT, "Static verification passed: " . count($required) . " required files, {$phpCount} PHP files.\n");
